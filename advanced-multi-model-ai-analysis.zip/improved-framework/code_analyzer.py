#!/usr/bin/env python3
"""
Code Analysis Tool using OpenRouter Models
Analyzes the AI Agent Framework and suggests improvements
"""

import os
import json
from typing import Dict, List, Any, Optional
from dataclasses import dataclass
from openai import OpenAI
import logging

# Configure logging
logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@dataclass
class CodeAnalysisResult:
    """Result from code analysis"""
    model_used: str
    analysis_type: str
    findings: List[Dict[str, Any]]
    recommendations: List[str]
    severity_score: int  # 1-10, 10 being most critical
    
class CodeAnalyzer:
    """Analyzes code using multiple OpenRouter models"""
    
    def __init__(self, api_key: str = None):
        """Initialize the code analyzer"""
        self.client = OpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=api_key or os.getenv("OPENROUTER_API_KEY"),
        )
        
        # Best models for different types of analysis
        self.models = {
            "security": "anthropic/claude-3.5-sonnet",  # Best for security analysis
            "architecture": "anthropic/claude-3.5-sonnet",  # Best for architecture review
            "performance": "deepseek/deepseek-v3-0324:free",  # Good for optimization
            "best_practices": "google/gemini-2.5-flash",  # Quick best practice checks
            "comprehensive": "anthropic/claude-3.5-sonnet"  # Overall comprehensive review
        }
        
    def analyze_file(self, file_path: str, analysis_type: str = "comprehensive") -> CodeAnalysisResult:
        """Analyze a single file"""
        try:
            with open(file_path, 'r', encoding='utf-8') as f:
                code_content = f.read()
            
            model = self.models.get(analysis_type, self.models["comprehensive"])
            prompt = self._get_analysis_prompt(analysis_type, code_content, file_path)
            
            logger.info(f"Analyzing {file_path} with {model} for {analysis_type}")
            
            response = self.client.chat.completions.create(
                model=model,
                messages=[{"role": "user", "content": prompt}],
                temperature=0.1,
                max_tokens=4000
            )
            
            result_text = response.choices[0].message.content
            return self._parse_analysis_result(result_text, model, analysis_type)
            
        except Exception as e:
            logger.error(f"Error analyzing {file_path}: {e}")
            return CodeAnalysisResult(
                model_used=model,
                analysis_type=analysis_type,
                findings=[{"type": "error", "message": str(e)}],
                recommendations=[],
                severity_score=1
            )
    
    def _get_analysis_prompt(self, analysis_type: str, code_content: str, file_path: str) -> str:
        """Get the appropriate prompt for the analysis type"""
        
        base_prompt = f"""
You are an expert code reviewer analyzing the file: {file_path}

Code to analyze:
```python
{code_content}
```

Please provide a detailed analysis focusing on {analysis_type}. Format your response as JSON with the following structure:
{{
    "findings": [
        {{
            "type": "security|performance|architecture|style|bug",
            "severity": "critical|high|medium|low",
            "line_number": number_or_null,
            "issue": "description of the issue",
            "explanation": "detailed explanation"
        }}
    ],
    "recommendations": [
        "specific actionable recommendation 1",
        "specific actionable recommendation 2"
    ],
    "severity_score": number_from_1_to_10,
    "summary": "brief summary of overall code quality"
}}
"""
        
        specific_prompts = {
            "security": base_prompt + """
            
Focus specifically on:
- Security vulnerabilities (SQL injection, XSS, code injection, etc.)
- Input validation issues
- Authentication and authorization flaws
- Data exposure risks
- Unsafe function usage (eval, exec, etc.)
- Cryptographic issues
""",
            
            "architecture": base_prompt + """
            
Focus specifically on:
- Code organization and structure
- Design patterns usage
- Separation of concerns
- Modularity and reusability
- Error handling patterns
- Scalability considerations
- Maintainability issues
""",
            
            "performance": base_prompt + """
            
Focus specifically on:
- Performance bottlenecks
- Memory usage issues
- Inefficient algorithms
- Database query optimization
- Caching opportunities
- Resource management
- Async/await usage
""",
            
            "best_practices": base_prompt + """
            
Focus specifically on:
- PEP 8 compliance
- Code style and formatting
- Naming conventions
- Documentation and comments
- Type hints usage
- Error handling best practices
- Testing considerations
""",
            
            "comprehensive": base_prompt + """
            
Provide a comprehensive analysis covering:
- Security vulnerabilities
- Architecture and design issues
- Performance problems
- Best practices violations
- Potential bugs
- Maintainability concerns
"""
        }
        
        return specific_prompts.get(analysis_type, specific_prompts["comprehensive"])
    
    def _parse_analysis_result(self, result_text: str, model: str, analysis_type: str) -> CodeAnalysisResult:
        """Parse the analysis result from the model"""
        try:
            # Try to extract JSON from the response
            import re
            json_match = re.search(r'\{.*\}', result_text, re.DOTALL)
            if json_match:
                result_json = json.loads(json_match.group())
                return CodeAnalysisResult(
                    model_used=model,
                    analysis_type=analysis_type,
                    findings=result_json.get("findings", []),
                    recommendations=result_json.get("recommendations", []),
                    severity_score=result_json.get("severity_score", 5)
                )
        except Exception as e:
            logger.warning(f"Failed to parse JSON result: {e}")
        
        # Fallback to text parsing
        findings = []
        recommendations = []
        
        lines = result_text.split('\n')
        current_section = None
        
        for line in lines:
            line = line.strip()
            if 'finding' in line.lower() or 'issue' in line.lower():
                current_section = 'findings'
            elif 'recommend' in line.lower() or 'suggest' in line.lower():
                current_section = 'recommendations'
            elif line.startswith('-') or line.startswith('*'):
                if current_section == 'findings':
                    findings.append({
                        "type": "general",
                        "severity": "medium",
                        "issue": line[1:].strip(),
                        "explanation": ""
                    })
                elif current_section == 'recommendations':
                    recommendations.append(line[1:].strip())
        
        return CodeAnalysisResult(
            model_used=model,
            analysis_type=analysis_type,
            findings=findings,
            recommendations=recommendations,
            severity_score=5
        )
    
    def analyze_framework(self) -> Dict[str, List[CodeAnalysisResult]]:
        """Analyze the entire framework"""
        results = {}
        
        # Files to analyze
        files_to_analyze = [
            "src/ai_agent_framework.py",
            "examples/interactive_demo.py"
        ]
        
        analysis_types = ["security", "architecture", "performance", "best_practices"]
        
        for file_path in files_to_analyze:
            if os.path.exists(file_path):
                results[file_path] = []
                for analysis_type in analysis_types:
                    result = self.analyze_file(file_path, analysis_type)
                    results[file_path].append(result)
            else:
                logger.warning(f"File not found: {file_path}")
        
        return results
    
    def generate_improvement_report(self, results: Dict[str, List[CodeAnalysisResult]]) -> str:
        """Generate a comprehensive improvement report"""
        report = []
        report.append("# AI Agent Framework - Code Analysis Report")
        report.append("=" * 50)
        report.append("")
        
        # Summary
        total_critical = 0
        total_high = 0
        total_findings = 0
        
        for file_path, file_results in results.items():
            report.append(f"## Analysis Results for {file_path}")
            report.append("")
            
            for result in file_results:
                report.append(f"### {result.analysis_type.title()} Analysis (Model: {result.model_used})")
                report.append(f"**Severity Score: {result.severity_score}/10**")
                report.append("")
                
                if result.findings:
                    report.append("**Findings:**")
                    for finding in result.findings:
                        severity = finding.get('severity', 'medium')
                        if severity == 'critical':
                            total_critical += 1
                        elif severity == 'high':
                            total_high += 1
                        total_findings += 1
                        
                        report.append(f"- **{severity.upper()}**: {finding.get('issue', 'Unknown issue')}")
                        if finding.get('explanation'):
                            report.append(f"  - {finding['explanation']}")
                    report.append("")
                
                if result.recommendations:
                    report.append("**Recommendations:**")
                    for rec in result.recommendations:
                        report.append(f"- {rec}")
                    report.append("")
                
                report.append("---")
                report.append("")
        
        # Add summary at the top
        summary = [
            f"## Executive Summary",
            f"- Total Findings: {total_findings}",
            f"- Critical Issues: {total_critical}",
            f"- High Priority Issues: {total_high}",
            f"- Analysis completed using top OpenRouter models",
            "",
            "---",
            ""
        ]
        
        return "\n".join(summary + report)

def main():
    """Main function to run code analysis"""
    # Check for API key
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        print("Error: OPENROUTER_API_KEY environment variable not set!")
        print("Please set your OpenRouter API key:")
        print("export OPENROUTER_API_KEY='your-api-key-here'")
        return
    
    analyzer = CodeAnalyzer(api_key)
    
    print("🔍 Starting comprehensive code analysis...")
    print("Using top OpenRouter models for different analysis types:")
    for analysis_type, model in analyzer.models.items():
        print(f"  - {analysis_type}: {model}")
    print()
    
    # Run analysis
    results = analyzer.analyze_framework()
    
    # Generate report
    report = analyzer.generate_improvement_report(results)
    
    # Save report
    with open("code_analysis_report.md", "w") as f:
        f.write(report)
    
    print("✅ Analysis complete! Report saved to code_analysis_report.md")
    print("\nKey findings summary:")
    
    # Print summary
    total_critical = 0
    total_high = 0
    for file_results in results.values():
        for result in file_results:
            for finding in result.findings:
                if finding.get('severity') == 'critical':
                    total_critical += 1
                elif finding.get('severity') == 'high':
                    total_high += 1
    
    print(f"- Critical issues found: {total_critical}")
    print(f"- High priority issues found: {total_high}")
    
    if total_critical > 0:
        print("\n⚠️  CRITICAL ISSUES DETECTED - Immediate attention required!")
    
    return results

if __name__ == "__main__":
    main()

