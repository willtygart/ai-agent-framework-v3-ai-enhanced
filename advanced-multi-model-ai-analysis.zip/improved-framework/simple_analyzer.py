#!/usr/bin/env python3
"""
Simple Code Analyzer - Real OpenRouter API calls
Analyzes one file with one model at a time to avoid timeouts
"""

import os
import json
from openai import OpenAI

def analyze_security(file_path: str, api_key: str):
    """Analyze security issues using Claude Sonnet"""
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=api_key
    )
    
    with open(file_path, 'r') as f:
        code = f.read()
    
    prompt = f"""
You are a security expert analyzing Python code. Please identify security vulnerabilities in this code:

```python
{code}
```

Focus on:
- Use of dangerous functions like eval(), exec()
- Input validation issues
- File operation security
- Authentication/authorization issues
- Data exposure risks

Provide your analysis in this JSON format:
{{
    "critical_issues": [
        {{
            "line": number_or_null,
            "issue": "description",
            "severity": "critical",
            "recommendation": "how to fix"
        }}
    ],
    "high_issues": [
        {{
            "line": number_or_null,
            "issue": "description", 
            "severity": "high",
            "recommendation": "how to fix"
        }}
    ],
    "summary": "overall security assessment"
}}
"""
    
    print(f"🔍 Analyzing {file_path} for security issues with Claude Sonnet...")
    
    response = client.chat.completions.create(
        model="anthropic/claude-3.5-sonnet",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,
        max_tokens=2000
    )
    
    return response.choices[0].message.content

def main():
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        print("Error: OPENROUTER_API_KEY not set!")
        return
    
    # Analyze the main framework file
    file_path = "src/ai_agent_framework.py"
    
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return
    
    try:
        result = analyze_security(file_path, api_key)
        print("\n" + "="*60)
        print("REAL AI SECURITY ANALYSIS RESULTS:")
        print("="*60)
        print(result)
        
        # Save results
        with open("real_security_analysis.txt", "w") as f:
            f.write(f"Security Analysis of {file_path}\n")
            f.write("="*50 + "\n\n")
            f.write(result)
        
        print(f"\n✅ Analysis saved to real_security_analysis.txt")
        
    except Exception as e:
        print(f"Error during analysis: {e}")

if __name__ == "__main__":
    main()

