#!/usr/bin/env python3
"""
Improved Tool Registry with Dependency Injection
Based on Gemini 2.5 Flash recommendations
"""

import logging
from typing import Dict, List, Any, Optional, Callable, Protocol
from dataclasses import dataclass
from abc import ABC, abstractmethod
import inspect

from .config import AgentConfig

logger = logging.getLogger(__name__)

@dataclass
class ToolResult:
    """Result from tool execution with enhanced error information"""
    success: bool
    result: str
    error: Optional[str] = None
    error_type: Optional[str] = None
    execution_time: Optional[float] = None

class Tool(Protocol):
    """Protocol for tool implementations"""
    
    def execute(self, **kwargs) -> ToolResult:
        """Execute the tool with given parameters"""
        ...
    
    def get_schema(self) -> str:
        """Get tool schema description"""
        ...
    
    def get_name(self) -> str:
        """Get tool name"""
        ...

class BaseTool(ABC):
    """Abstract base class for tools"""
    
    def __init__(self, config: AgentConfig):
        self.config = config
    
    @abstractmethod
    def execute(self, **kwargs) -> ToolResult:
        """Execute the tool"""
        pass
    
    @abstractmethod
    def get_schema(self) -> str:
        """Get tool schema"""
        pass
    
    @abstractmethod
    def get_name(self) -> str:
        """Get tool name"""
        pass
    
    def _handle_error(self, error: Exception, context: str = "") -> ToolResult:
        """Standard error handling for tools"""
        error_type = type(error).__name__
        error_msg = str(error)
        
        logger.error(f"Tool {self.get_name()} error in {context}: {error_type}: {error_msg}")
        
        return ToolResult(
            success=False,
            result="",
            error=error_msg,
            error_type=error_type
        )

class ImprovedToolRegistry:
    """Enhanced tool registry with dependency injection and better error handling"""
    
    def __init__(self, config: AgentConfig):
        self.config = config
        self.tools: Dict[str, Tool] = {}
        self.tool_schemas: Dict[str, str] = {}
        self._enabled_tools: Dict[str, bool] = {}
        
    def register_tool(self, tool: Tool, enabled: bool = True) -> None:
        """Register a tool instance"""
        name = tool.get_name()
        schema = tool.get_schema()
        
        self.tools[name] = tool
        self.tool_schemas[name] = schema
        self._enabled_tools[name] = enabled
        
        logger.info(f"Registered tool: {name} (enabled: {enabled})")
    
    def register_function_tool(self, name: str, func: Callable, schema: str, enabled: bool = True) -> None:
        """Register a function as a tool (backward compatibility)"""
        tool = FunctionTool(name, func, schema, self.config)
        self.register_tool(tool, enabled)
    
    def enable_tool(self, name: str) -> None:
        """Enable a tool"""
        if name in self.tools:
            self._enabled_tools[name] = True
            logger.info(f"Enabled tool: {name}")
        else:
            logger.warning(f"Cannot enable unknown tool: {name}")
    
    def disable_tool(self, name: str) -> None:
        """Disable a tool"""
        if name in self.tools:
            self._enabled_tools[name] = False
            logger.info(f"Disabled tool: {name}")
        else:
            logger.warning(f"Cannot disable unknown tool: {name}")
    
    def get_enabled_tools(self) -> List[str]:
        """Get list of enabled tool names"""
        return [name for name, enabled in self._enabled_tools.items() if enabled]
    
    def get_tool_schemas(self) -> str:
        """Get formatted tool schemas for enabled tools only"""
        enabled_tools = self.get_enabled_tools()
        if not enabled_tools:
            return "No tools available"
        
        schemas = ["Available Tools:"]
        for i, name in enumerate(enabled_tools, 1):
            schemas.append(f"{i}. {self.tool_schemas[name]}")
        return "\n".join(schemas)
    
    def execute_tool(self, name: str, **kwargs) -> ToolResult:
        """Execute a tool with enhanced error handling"""
        import time
        
        # Check if tool exists
        if name not in self.tools:
            return ToolResult(
                success=False,
                result="",
                error=f"Tool '{name}' not found",
                error_type="ToolNotFoundError"
            )
        
        # Check if tool is enabled
        if not self._enabled_tools.get(name, False):
            return ToolResult(
                success=False,
                result="",
                error=f"Tool '{name}' is disabled",
                error_type="ToolDisabledError"
            )
        
        # Execute tool with timing
        start_time = time.time()
        try:
            tool = self.tools[name]
            result = tool.execute(**kwargs)
            result.execution_time = time.time() - start_time
            
            logger.debug(f"Tool {name} executed in {result.execution_time:.3f}s")
            return result
            
        except Exception as e:
            execution_time = time.time() - start_time
            logger.error(f"Unexpected error executing tool {name}: {e}")
            
            return ToolResult(
                success=False,
                result="",
                error=f"Unexpected error: {e}",
                error_type=type(e).__name__,
                execution_time=execution_time
            )
    
    def get_tool_info(self) -> Dict[str, Any]:
        """Get information about all registered tools"""
        return {
            "total_tools": len(self.tools),
            "enabled_tools": len(self.get_enabled_tools()),
            "tools": {
                name: {
                    "enabled": self._enabled_tools.get(name, False),
                    "schema": schema
                }
                for name, schema in self.tool_schemas.items()
            }
        }

class FunctionTool(BaseTool):
    """Wrapper to convert functions to tools"""
    
    def __init__(self, name: str, func: Callable, schema: str, config: AgentConfig):
        super().__init__(config)
        self.name = name
        self.func = func
        self.schema = schema
    
    def get_name(self) -> str:
        return self.name
    
    def get_schema(self) -> str:
        return self.schema
    
    def execute(self, **kwargs) -> ToolResult:
        """Execute the wrapped function"""
        try:
            # Validate parameters against function signature
            sig = inspect.signature(self.func)
            
            # Filter kwargs to only include valid parameters
            valid_kwargs = {}
            for param_name in sig.parameters:
                if param_name in kwargs:
                    valid_kwargs[param_name] = kwargs[param_name]
            
            # Execute function
            result = self.func(**valid_kwargs)
            
            return ToolResult(
                success=True,
                result=str(result)
            )
            
        except TypeError as e:
            return self._handle_error(e, "parameter validation")
        except Exception as e:
            return self._handle_error(e, "function execution")

def create_tool_registry(config: AgentConfig) -> ImprovedToolRegistry:
    """Factory function to create and configure tool registry"""
    registry = ImprovedToolRegistry(config)
    
    # Register tools based on configuration
    if config.enable_file_operations:
        from .tools.file_tools import SecureFileWriteTool, SecureFileReadTool
        registry.register_tool(SecureFileWriteTool(config))
        registry.register_tool(SecureFileReadTool(config))
    
    if config.enable_calculator:
        from .tools.math_tools import SecureCalculatorTool
        registry.register_tool(SecureCalculatorTool(config))
    
    if config.enable_web_search:
        from .tools.web_tools import WebSearchTool
        registry.register_tool(WebSearchTool(config))
    
    # Always register utility tools
    from .tools.utility_tools import CurrentTimeTool, ModelListTool
    registry.register_tool(CurrentTimeTool(config))
    registry.register_tool(ModelListTool(config))
    
    return registry

