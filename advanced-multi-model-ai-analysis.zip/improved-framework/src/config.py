#!/usr/bin/env python3
"""
Configuration Management for AI Agent Framework
Based on Gemini 2.5 Flash recommendations
"""

import os
from dataclasses import dataclass
from typing import Optional
from pathlib import Path

@dataclass
class AgentConfig:
    """Configuration for AI Agent"""
    
    # API Configuration
    openrouter_api_key: str
    openrouter_base_url: str = "https://openrouter.ai/api/v1"
    
    # Agent Configuration
    default_model: str = "anthropic/claude-3.5-sonnet"
    max_iterations: int = 10
    temperature: float = 0.1
    max_tokens: int = 2000
    
    # Security Configuration
    sandbox_dir: str = "./sandbox"
    max_file_size_mb: int = 10
    max_input_length: int = 10000
    max_expression_length: int = 200
    
    # Tool Configuration
    enable_web_search: bool = True
    enable_file_operations: bool = True
    enable_calculator: bool = True
    
    # Logging Configuration
    log_level: str = "INFO"
    log_format: str = "%(asctime)s - %(levelname)s - %(message)s"
    
    @classmethod
    def from_env(cls) -> 'AgentConfig':
        """Create configuration from environment variables"""
        api_key = os.getenv("OPENROUTER_API_KEY")
        if not api_key:
            raise ValueError("OPENROUTER_API_KEY environment variable is required")
        
        return cls(
            openrouter_api_key=api_key,
            openrouter_base_url=os.getenv("OPENROUTER_BASE_URL", cls.openrouter_base_url),
            default_model=os.getenv("DEFAULT_MODEL", cls.default_model),
            max_iterations=int(os.getenv("MAX_ITERATIONS", cls.max_iterations)),
            temperature=float(os.getenv("TEMPERATURE", cls.temperature)),
            max_tokens=int(os.getenv("MAX_TOKENS", cls.max_tokens)),
            sandbox_dir=os.getenv("SANDBOX_DIR", cls.sandbox_dir),
            max_file_size_mb=int(os.getenv("MAX_FILE_SIZE_MB", cls.max_file_size_mb)),
            max_input_length=int(os.getenv("MAX_INPUT_LENGTH", cls.max_input_length)),
            max_expression_length=int(os.getenv("MAX_EXPRESSION_LENGTH", cls.max_expression_length)),
            enable_web_search=os.getenv("ENABLE_WEB_SEARCH", "true").lower() == "true",
            enable_file_operations=os.getenv("ENABLE_FILE_OPERATIONS", "true").lower() == "true",
            enable_calculator=os.getenv("ENABLE_CALCULATOR", "true").lower() == "true",
            log_level=os.getenv("LOG_LEVEL", cls.log_level),
            log_format=os.getenv("LOG_FORMAT", cls.log_format)
        )
    
    @classmethod
    def from_file(cls, config_path: str) -> 'AgentConfig':
        """Create configuration from file (future enhancement)"""
        # This could load from JSON, YAML, or TOML files
        # For now, just use environment variables
        return cls.from_env()
    
    def validate(self) -> None:
        """Validate configuration values"""
        if not self.openrouter_api_key:
            raise ValueError("OpenRouter API key is required")
        
        if self.max_iterations < 1:
            raise ValueError("max_iterations must be at least 1")
        
        if self.temperature < 0 or self.temperature > 2:
            raise ValueError("temperature must be between 0 and 2")
        
        if self.max_tokens < 100:
            raise ValueError("max_tokens must be at least 100")
        
        if self.max_file_size_mb < 1:
            raise ValueError("max_file_size_mb must be at least 1")
        
        # Create sandbox directory if it doesn't exist
        Path(self.sandbox_dir).mkdir(parents=True, exist_ok=True)
    
    def to_dict(self) -> dict:
        """Convert configuration to dictionary"""
        return {
            'openrouter_api_key': '***REDACTED***',  # Don't expose API key
            'openrouter_base_url': self.openrouter_base_url,
            'default_model': self.default_model,
            'max_iterations': self.max_iterations,
            'temperature': self.temperature,
            'max_tokens': self.max_tokens,
            'sandbox_dir': self.sandbox_dir,
            'max_file_size_mb': self.max_file_size_mb,
            'max_input_length': self.max_input_length,
            'max_expression_length': self.max_expression_length,
            'enable_web_search': self.enable_web_search,
            'enable_file_operations': self.enable_file_operations,
            'enable_calculator': self.enable_calculator,
            'log_level': self.log_level
        }

# Global configuration instance
_config: Optional[AgentConfig] = None

def get_config() -> AgentConfig:
    """Get the global configuration instance"""
    global _config
    if _config is None:
        _config = AgentConfig.from_env()
        _config.validate()
    return _config

def set_config(config: AgentConfig) -> None:
    """Set the global configuration instance"""
    global _config
    config.validate()
    _config = config

def reset_config() -> None:
    """Reset the global configuration instance"""
    global _config
    _config = None

