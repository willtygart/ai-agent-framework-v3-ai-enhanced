#!/usr/bin/env python3
"""
Utility Tools
"""

import os
from datetime import datetime
from pathlib import Path
from ..improved_registry import BaseTool, ToolResult
from ..config import AgentConfig

class CurrentTimeTool(BaseTool):
    """Tool to get current date and time"""
    
    def get_name(self) -> str:
        return "get_current_time"
    
    def get_schema(self) -> str:
        return "get_current_time() -> str - Get the current date and time"
    
    def execute(self, **kwargs) -> ToolResult:
        """Get current time"""
        try:
            current_time = datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            return ToolResult(
                success=True,
                result=f"Current time: {current_time}"
            )
        except Exception as e:
            return self._handle_error(e, "time retrieval")

class ModelListTool(BaseTool):
    """Tool to list OpenRouter models"""
    
    def get_name(self) -> str:
        return "list_openrouter_models"
    
    def get_schema(self) -> str:
        return "list_openrouter_models(category: str = 'all') -> str - List OpenRouter models by category"
    
    def execute(self, **kwargs) -> ToolResult:
        """List OpenRouter models"""
        try:
            category = kwargs.get('category', 'all')
            
            # Try to load model data
            try:
                import pandas as pd
                import glob
                
                # Look for models data in the data directory
                data_dir = Path(__file__).parent.parent.parent / 'data'
                csv_files = list(data_dir.glob('top_100_openrouter_models_*.csv'))
                
                if not csv_files:
                    # Fallback to current directory
                    csv_files = list(Path.cwd().glob('top_100_openrouter_models_*.csv'))
                
                if not csv_files:
                    return ToolResult(
                        success=False,
                        result="",
                        error="Top 100 models data not found",
                        error_type="DataNotFoundError"
                    )
                
                # Load the most recent file
                df = pd.read_csv(max(csv_files))
                
                # Filter by category
                if category == "free":
                    models = df[df['is_free'] == True] if 'is_free' in df.columns else df.head(10)
                elif category == "programming":
                    models = df[df['id'].str.contains('code|dev|programming', case=False, na=False)] if 'id' in df.columns else df.head(10)
                elif category == "reasoning":
                    models = df[df['id'].str.contains('reasoning|think|r1|o1', case=False, na=False)] if 'id' in df.columns else df.head(10)
                elif category == "fast":
                    models = df[df['id'].str.contains('flash|fast|lite|mini', case=False, na=False)] if 'id' in df.columns else df.head(10)
                else:
                    models = df.head(20)  # Top 20 for "all"
                
                # Format results
                result_lines = [f"OpenRouter Models ({category}):"]
                for _, model in models.head(10).iterrows():
                    model_id = model.get('id', 'unknown')
                    score = model.get('total_score', 0)
                    is_free = model.get('is_free', False)
                    cost = "FREE" if is_free else f"${model.get('input_cost', 0):.4f}/M"
                    result_lines.append(f"- {model_id} (Score: {score:.1f}, Cost: {cost})")
                
                return ToolResult(
                    success=True,
                    result="\n".join(result_lines)
                )
                
            except ImportError:
                # Fallback if pandas is not available
                fallback_models = {
                    'all': [
                        'anthropic/claude-3.5-sonnet',
                        'google/gemini-2.5-flash',
                        'deepseek/deepseek-v3',
                        'openai/gpt-4.1',
                        'google/gemini-2.5-pro'
                    ],
                    'free': [
                        'deepseek/deepseek-v3:free',
                        'google/gemini-2.5-flash-lite'
                    ],
                    'programming': [
                        'anthropic/claude-3.5-sonnet',
                        'deepseek/deepseek-v3'
                    ]
                }
                
                models = fallback_models.get(category, fallback_models['all'])
                result_lines = [f"OpenRouter Models ({category}) - Fallback List:"]
                for i, model in enumerate(models, 1):
                    result_lines.append(f"{i}. {model}")
                
                return ToolResult(
                    success=True,
                    result="\n".join(result_lines)
                )
                
        except Exception as e:
            return self._handle_error(e, "model listing")

