#!/usr/bin/env python3
"""
Secure Mathematical Calculation Tools
"""

import ast
import operator
from ..improved_registry import BaseTool, ToolResult
from ..config import AgentConfig

class SecureCalculatorTool(BaseTool):
    """Secure calculator using AST parsing instead of eval()"""
    
    # Safe math operations mapping
    SAFE_OPERATORS = {
        ast.Add: operator.add,
        ast.Sub: operator.sub,
        ast.Mult: operator.mul,
        ast.Div: operator.truediv,
        ast.Pow: operator.pow,
        ast.Mod: operator.mod,
        ast.USub: operator.neg,
        ast.UAdd: operator.pos,
    }
    
    ALLOWED_NAMES = {
        'pi': 3.141592653589793,
        'e': 2.718281828459045,
    }
    
    def get_name(self) -> str:
        return "calculate"
    
    def get_schema(self) -> str:
        return "calculate(expression: str) -> str - Safely calculate mathematical expressions"
    
    def execute(self, **kwargs) -> ToolResult:
        """Execute secure calculation"""
        try:
            expression = kwargs.get('expression', '')
            
            if not expression:
                return ToolResult(
                    success=False,
                    result="",
                    error="expression parameter is required",
                    error_type="MissingParameterError"
                )
            
            # Validate expression
            validation_result = self._validate_expression(expression)
            if not validation_result.success:
                return validation_result
            
            # Parse and evaluate safely
            result = self._safe_evaluate(expression)
            
            return ToolResult(
                success=True,
                result=f"Result: {result}"
            )
            
        except Exception as e:
            return self._handle_error(e, "calculation")
    
    def _validate_expression(self, expression: str) -> ToolResult:
        """Validate mathematical expression"""
        # Check length
        if len(expression) > self.config.max_expression_length:
            return ToolResult(
                success=False,
                result="",
                error=f"Expression too long (max: {self.config.max_expression_length} chars)",
                error_type="ExpressionTooLongError"
            )
        
        # Check for allowed characters only
        allowed_chars = set('0123456789+-*/()., pie')
        if not all(c in allowed_chars for c in expression.replace(' ', '')):
            return ToolResult(
                success=False,
                result="",
                error="Invalid characters in expression",
                error_type="InvalidCharacterError"
            )
        
        return ToolResult(success=True, result="")
    
    def _safe_evaluate(self, expression: str) -> float:
        """Safely evaluate mathematical expression using AST"""
        try:
            # Parse expression into AST
            node = ast.parse(expression, mode='eval')
            return self._eval_node(node.body)
        except Exception as e:
            raise ValueError(f"Invalid mathematical expression: {e}")
    
    def _eval_node(self, node):
        """Recursively evaluate AST nodes safely"""
        if isinstance(node, ast.Constant):  # Numbers
            return node.value
        elif isinstance(node, ast.Name):  # Variables like pi, e
            if node.id in self.ALLOWED_NAMES:
                return self.ALLOWED_NAMES[node.id]
            else:
                raise ValueError(f"Unknown variable: {node.id}")
        elif isinstance(node, ast.BinOp):  # Binary operations
            left = self._eval_node(node.left)
            right = self._eval_node(node.right)
            op_type = type(node.op)
            if op_type in self.SAFE_OPERATORS:
                return self.SAFE_OPERATORS[op_type](left, right)
            else:
                raise ValueError(f"Unsupported operation: {op_type}")
        elif isinstance(node, ast.UnaryOp):  # Unary operations
            operand = self._eval_node(node.operand)
            op_type = type(node.op)
            if op_type in self.SAFE_OPERATORS:
                return self.SAFE_OPERATORS[op_type](operand)
            else:
                raise ValueError(f"Unsupported unary operation: {op_type}")
        else:
            raise ValueError(f"Unsupported node type: {type(node)}")

