#!/usr/bin/env python3
"""
Secure File Operation Tools
"""

import os
import time
from pathlib import Path
from ..improved_registry import BaseTool, ToolResult
from ..config import AgentConfig

class SecureFileWriteTool(BaseTool):
    """Secure file writing tool with sandboxing"""
    
    def get_name(self) -> str:
        return "write_file"
    
    def get_schema(self) -> str:
        return "write_file(filename: str, content: str) -> str - Write content to a file in sandbox"
    
    def execute(self, **kwargs) -> ToolResult:
        """Execute secure file write"""
        try:
            filename = kwargs.get('filename', '')
            content = kwargs.get('content', '')
            
            if not filename:
                return ToolResult(
                    success=False,
                    result="",
                    error="filename parameter is required",
                    error_type="MissingParameterError"
                )
            
            if not isinstance(content, str):
                content = str(content)
            
            # Create sandbox directory
            sandbox_dir = Path(self.config.sandbox_dir).resolve()
            sandbox_dir.mkdir(parents=True, exist_ok=True)
            
            # Sanitize filename (remove path components)
            safe_filename = Path(filename).name
            safe_path = sandbox_dir / safe_filename
            
            # Check content size
            content_size_mb = len(content.encode('utf-8')) / (1024 * 1024)
            if content_size_mb > self.config.max_file_size_mb:
                return ToolResult(
                    success=False,
                    result="",
                    error=f"Content too large ({content_size_mb:.1f}MB, max: {self.config.max_file_size_mb}MB)",
                    error_type="FileSizeError"
                )
            
            # Write file
            with open(safe_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            return ToolResult(
                success=True,
                result=f"Successfully wrote content to {safe_filename} (in sandbox)"
            )
            
        except PermissionError as e:
            return self._handle_error(e, "file permissions")
        except OSError as e:
            return self._handle_error(e, "file system operation")
        except Exception as e:
            return self._handle_error(e, "file write")

class SecureFileReadTool(BaseTool):
    """Secure file reading tool with sandboxing"""
    
    def get_name(self) -> str:
        return "read_file"
    
    def get_schema(self) -> str:
        return "read_file(filename: str) -> str - Read content from a file in sandbox"
    
    def execute(self, **kwargs) -> ToolResult:
        """Execute secure file read"""
        try:
            filename = kwargs.get('filename', '')
            
            if not filename:
                return ToolResult(
                    success=False,
                    result="",
                    error="filename parameter is required",
                    error_type="MissingParameterError"
                )
            
            # Sandbox directory
            sandbox_dir = Path(self.config.sandbox_dir).resolve()
            
            # Sanitize filename (remove path components)
            safe_filename = Path(filename).name
            safe_path = sandbox_dir / safe_filename
            
            # Check if file exists
            if not safe_path.exists():
                return ToolResult(
                    success=False,
                    result="",
                    error=f"File '{safe_filename}' not found in sandbox",
                    error_type="FileNotFoundError"
                )
            
            # Check file size
            size_mb = safe_path.stat().st_size / (1024 * 1024)
            if size_mb > self.config.max_file_size_mb:
                return ToolResult(
                    success=False,
                    result="",
                    error=f"File too large ({size_mb:.1f}MB, max: {self.config.max_file_size_mb}MB)",
                    error_type="FileSizeError"
                )
            
            # Read file
            with open(safe_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            return ToolResult(
                success=True,
                result=f"File content:\n{content}"
            )
            
        except PermissionError as e:
            return self._handle_error(e, "file permissions")
        except UnicodeDecodeError as e:
            return self._handle_error(e, "file encoding")
        except OSError as e:
            return self._handle_error(e, "file system operation")
        except Exception as e:
            return self._handle_error(e, "file read")

