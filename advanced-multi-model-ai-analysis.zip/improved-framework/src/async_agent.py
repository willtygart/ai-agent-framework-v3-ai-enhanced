#!/usr/bin/env python3
"""
Async AI Agent with Streaming Support
Based on Claude Sonnet 3.5 advanced features analysis
"""

import asyncio
import logging
from typing import List, Dict, Any, Optional, AsyncIterator
from openai import AsyncOpenAI
import time

from .config import AgentConfig, get_config
from .improved_registry import ImprovedToolRegistry, create_tool_registry
from .parsers import LLMOutputParser, get_default_parser, ParseResult

logger = logging.getLogger(__name__)

class AsyncAIAgent:
    """Async AI Agent with streaming and parallel tool execution"""
    
    def __init__(self, 
                 config: Optional[AgentConfig] = None,
                 tool_registry: Optional[ImprovedToolRegistry] = None,
                 output_parser: Optional[LLMOutputParser] = None,
                 client: Optional[AsyncOpenAI] = None):
        """Initialize async agent with dependency injection"""
        
        # Use provided config or get default
        self.config = config or get_config()
        
        # Set up logging
        logging.basicConfig(
            level=getattr(logging, self.config.log_level),
            format=self.config.log_format
        )
        
        # Inject dependencies
        self.tool_registry = tool_registry or create_tool_registry(self.config)
        self.output_parser = output_parser or get_default_parser()
        self.client = client or AsyncOpenAI(
            base_url=self.config.openrouter_base_url,
            api_key=self.config.openrouter_api_key,
        )
        
        # Agent state
        self.conversation_history: List[Dict[str, str]] = []
        self.current_model = self.config.default_model
        
        # Performance tracking
        self.metrics = {
            'total_requests': 0,
            'total_tokens': 0,
            'total_time': 0.0,
            'tool_executions': 0
        }
        
        logger.info(f"Initialized AsyncAIAgent with model: {self.current_model}")
        logger.info(f"Available tools: {', '.join(self.tool_registry.get_enabled_tools())}")
    
    async def run(self, user_request: str, model: Optional[str] = None) -> str:
        """Run the agent asynchronously"""
        start_time = time.time()
        
        try:
            # Use specified model or default
            model_to_use = model or self.current_model
            
            # Validate input
            if len(user_request) > self.config.max_input_length:
                return f"Error: Request too long (max: {self.config.max_input_length} characters)"
            
            logger.info(f"Starting async agent run for request: {user_request[:100]}...")
            
            # Initialize conversation
            master_prompt = self._create_master_prompt(user_request)
            self.conversation_history = [{"role": "user", "content": master_prompt}]
            
            # Main reasoning loop
            for iteration in range(self.config.max_iterations):
                logger.info(f"--- Async Iteration {iteration + 1} ---")
                
                try:
                    # Call LLM asynchronously
                    llm_response = await self._call_llm_async(model_to_use)
                    self.conversation_history.append({"role": "assistant", "content": llm_response})
                    
                    logger.debug(f"LLM Response:\n{llm_response}")
                    
                    # Parse response
                    parse_result = self.output_parser.parse(llm_response)
                    
                    # Handle parsing result
                    if parse_result.is_final_answer:
                        if parse_result.final_answer:
                            logger.info("Task completed successfully!")
                            return parse_result.final_answer
                        else:
                            logger.warning("Empty final answer received")
                            return "Task completed, but no final answer was provided."
                    
                    elif parse_result.error:
                        # Parsing error - provide feedback to LLM
                        error_feedback = f"Observation: Parsing error: {parse_result.error}. Please use the correct format."
                        self.conversation_history.append({"role": "user", "content": error_feedback})
                        logger.warning(f"Parsing error: {parse_result.error}")
                        continue
                    
                    elif parse_result.action:
                        # Execute action asynchronously
                        tool_result = await self._execute_tool_async(
                            parse_result.action.tool_name,
                            **parse_result.action.parameters
                        )
                        
                        # Create observation
                        observation = f"Observation: {tool_result.result}"
                        if not tool_result.success and tool_result.error:
                            observation += f" (Error: {tool_result.error})"
                        
                        logger.info(f"Tool Result: {observation}")
                        self.conversation_history.append({"role": "user", "content": observation})
                    
                    else:
                        # No action or final answer found
                        feedback = "Observation: No valid action or final answer found."
                        self.conversation_history.append({"role": "user", "content": feedback})
                        logger.warning("No valid action or final answer in LLM response")
                
                except Exception as e:
                    logger.error(f"Error in iteration {iteration + 1}: {e}")
                    error_feedback = f"Observation: System error occurred: {e}. Please try a different approach."
                    self.conversation_history.append({"role": "user", "content": error_feedback})
            
            # Max iterations reached
            logger.warning("Maximum iterations reached without completion")
            return "I apologize, but I wasn't able to complete the task within the maximum number of iterations."
        
        except Exception as e:
            logger.error(f"Fatal error in async agent run: {e}")
            return f"A fatal error occurred: {e}. Please try again or contact support."
        
        finally:
            # Update metrics
            self.metrics['total_requests'] += 1
            self.metrics['total_time'] += time.time() - start_time
    
    async def run_streaming(self, user_request: str, model: Optional[str] = None) -> AsyncIterator[str]:
        """Run the agent with streaming responses"""
        model_to_use = model or self.current_model
        
        # Validate input
        if len(user_request) > self.config.max_input_length:
            yield f"Error: Request too long (max: {self.config.max_input_length} characters)"
            return
        
        logger.info(f"Starting streaming agent run for request: {user_request[:100]}...")
        
        # Initialize conversation
        master_prompt = self._create_master_prompt(user_request)
        self.conversation_history = [{"role": "user", "content": master_prompt}]
        
        # Main reasoning loop
        for iteration in range(self.config.max_iterations):
            yield f"\n--- Iteration {iteration + 1} ---\n"
            
            try:
                # Stream LLM response
                llm_response = ""
                async for chunk in self._stream_llm_async(model_to_use):
                    llm_response += chunk
                    yield chunk
                
                self.conversation_history.append({"role": "assistant", "content": llm_response})
                
                # Parse response
                parse_result = self.output_parser.parse(llm_response)
                
                # Handle parsing result
                if parse_result.is_final_answer:
                    if parse_result.final_answer:
                        yield f"\n\n✅ Final Answer: {parse_result.final_answer}"
                        return
                    else:
                        yield "\n\n⚠️ Task completed, but no final answer was provided."
                        return
                
                elif parse_result.error:
                    yield f"\n\n❌ Parsing Error: {parse_result.error}"
                    error_feedback = f"Observation: Parsing error: {parse_result.error}. Please use the correct format."
                    self.conversation_history.append({"role": "user", "content": error_feedback})
                    continue
                
                elif parse_result.action:
                    yield f"\n\n🔧 Executing tool: {parse_result.action.tool_name}"
                    
                    # Execute action asynchronously
                    tool_result = await self._execute_tool_async(
                        parse_result.action.tool_name,
                        **parse_result.action.parameters
                    )
                    
                    # Create observation
                    observation = f"Observation: {tool_result.result}"
                    if not tool_result.success and tool_result.error:
                        observation += f" (Error: {tool_result.error})"
                    
                    yield f"\n📋 {observation}"
                    self.conversation_history.append({"role": "user", "content": observation})
                
                else:
                    yield "\n\n⚠️ No valid action or final answer found."
                    feedback = "Observation: No valid action or final answer found."
                    self.conversation_history.append({"role": "user", "content": feedback})
            
            except Exception as e:
                yield f"\n\n❌ Error in iteration {iteration + 1}: {e}"
                error_feedback = f"Observation: System error occurred: {e}. Please try a different approach."
                self.conversation_history.append({"role": "user", "content": error_feedback})
        
        yield "\n\n⚠️ Maximum iterations reached without completion."
    
    async def _call_llm_async(self, model: str) -> str:
        """Call the LLM asynchronously"""
        try:
            response = await self.client.chat.completions.create(
                model=model,
                messages=self.conversation_history,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens
            )
            
            # Update metrics
            if hasattr(response, 'usage') and response.usage:
                self.metrics['total_tokens'] += response.usage.total_tokens
            
            return response.choices[0].message.content
            
        except Exception as e:
            logger.error(f"Async LLM API call failed: {e}")
            raise RuntimeError(f"Failed to get response from LLM: {e}")
    
    async def _stream_llm_async(self, model: str) -> AsyncIterator[str]:
        """Stream LLM response asynchronously"""
        try:
            stream = await self.client.chat.completions.create(
                model=model,
                messages=self.conversation_history,
                temperature=self.config.temperature,
                max_tokens=self.config.max_tokens,
                stream=True
            )
            
            async for chunk in stream:
                if chunk.choices[0].delta.content is not None:
                    yield chunk.choices[0].delta.content
                    
        except Exception as e:
            logger.error(f"Async LLM streaming failed: {e}")
            yield f"Error: Failed to stream response from LLM: {e}"
    
    async def _execute_tool_async(self, name: str, **kwargs):
        """Execute tool asynchronously (wrapper for sync tools)"""
        # For now, wrap sync tool execution in async
        # TODO: Convert tools to async for true parallelism
        loop = asyncio.get_event_loop()
        
        def sync_execute():
            self.metrics['tool_executions'] += 1
            return self.tool_registry.execute_tool(name, **kwargs)
        
        return await loop.run_in_executor(None, sync_execute)
    
    def _create_master_prompt(self, user_request: str) -> str:
        """Create the master prompt with current tool schemas"""
        tool_schemas = self.tool_registry.get_tool_schemas()
        
        return f"""You are a helpful, autonomous AI agent. Your goal is to solve the user's request by breaking it down and using the available tools.

You have access to the following tools:
{tool_schemas}

Follow this exact format for your responses:
Thought: Your step-by-step reasoning about what you need to do next.
Action: The name of the single tool to use from the list above.
Action Input: The parameters for the chosen tool in the format: param1="value1", param2="value2"
Observation: (This is filled in by the system after the tool runs)

If you have enough information to answer the user's request, you MUST respond with:
Final Answer: Your final, complete response to the user.

Important guidelines:
- Always think step by step before taking action
- Use tools to gather information or perform tasks
- Only provide a Final Answer when you have sufficient information
- If a tool fails, try alternative approaches
- Be thorough and accurate in your responses

Begin!
User's Request: {user_request}"""
    
    def get_metrics(self) -> Dict[str, Any]:
        """Get performance metrics"""
        return {
            **self.metrics,
            'avg_time_per_request': self.metrics['total_time'] / max(1, self.metrics['total_requests']),
            'avg_tokens_per_request': self.metrics['total_tokens'] / max(1, self.metrics['total_requests'])
        }

# Convenience function
async def create_async_agent(api_key: Optional[str] = None, model: str = "anthropic/claude-3.5-sonnet") -> AsyncAIAgent:
    """Create an async agent with default configuration"""
    if api_key:
        import os
        os.environ["OPENROUTER_API_KEY"] = api_key
    
    config = get_config()
    config.default_model = model
    
    return AsyncAIAgent(config=config)

