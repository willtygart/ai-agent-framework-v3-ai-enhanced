#!/usr/bin/env python3
"""
LLM Output Parsers using Strategy Pattern
Based on Gemini 2.5 Flash recommendations
"""

import re
import json
import logging
from abc import ABC, abstractmethod
from typing import Dict, Optional, Tuple, Any
from dataclasses import dataclass

logger = logging.getLogger(__name__)

@dataclass
class ParsedAction:
    """Parsed action from LLM output"""
    tool_name: str
    parameters: Dict[str, Any]
    raw_text: str
    confidence: float = 1.0  # Confidence in parsing accuracy

@dataclass
class ParseResult:
    """Result of parsing LLM output"""
    is_final_answer: bool
    final_answer: Optional[str] = None
    action: Optional[ParsedAction] = None
    thought: Optional[str] = None
    error: Optional[str] = None

class LLMOutputParser(ABC):
    """Abstract base class for LLM output parsers"""
    
    @abstractmethod
    def parse(self, llm_output: str) -> ParseResult:
        """Parse LLM output and extract action or final answer"""
        pass
    
    @abstractmethod
    def get_name(self) -> str:
        """Get parser name for logging"""
        pass

class ReActTextParser(LLMOutputParser):
    """Parser for ReAct pattern text format"""
    
    def get_name(self) -> str:
        return "ReActTextParser"
    
    def parse(self, llm_output: str) -> ParseResult:
        """Parse ReAct format: Thought: ... Action: ... Action Input: ..."""
        try:
            # Check for Final Answer first
            if "Final Answer:" in llm_output:
                final_answer = llm_output.split("Final Answer:")[-1].strip()
                return ParseResult(
                    is_final_answer=True,
                    final_answer=final_answer,
                    thought=self._extract_thought(llm_output)
                )
            
            # Extract components
            thought = self._extract_thought(llm_output)
            action_result = self._extract_action(llm_output)
            
            if action_result is None:
                return ParseResult(
                    is_final_answer=False,
                    error="No valid action found in LLM output",
                    thought=thought
                )
            
            return ParseResult(
                is_final_answer=False,
                action=action_result,
                thought=thought
            )
            
        except Exception as e:
            logger.error(f"Error parsing ReAct output: {e}")
            return ParseResult(
                is_final_answer=False,
                error=f"Parsing error: {e}"
            )
    
    def _extract_thought(self, text: str) -> Optional[str]:
        """Extract thought from text"""
        thought_match = re.search(r"Thought:\s*(.+?)(?=Action:|Final Answer:|$)", text, re.DOTALL)
        if thought_match:
            return thought_match.group(1).strip()
        return None
    
    def _extract_action(self, text: str) -> Optional[ParsedAction]:
        """Extract action and parameters from text"""
        # Extract Action
        action_match = re.search(r"Action:\s*(\w+)", text)
        if not action_match:
            return None
        
        tool_name = action_match.group(1)
        
        # Extract Action Input
        input_match = re.search(r"Action Input:\s*(.+?)(?=\n|$)", text, re.DOTALL)
        if not input_match:
            return ParsedAction(
                tool_name=tool_name,
                parameters={},
                raw_text=text,
                confidence=0.5
            )
        
        input_text = input_match.group(1).strip()
        parameters = self._parse_parameters(input_text, tool_name)
        
        return ParsedAction(
            tool_name=tool_name,
            parameters=parameters,
            raw_text=text,
            confidence=0.9 if parameters else 0.6
        )
    
    def _parse_parameters(self, input_text: str, tool_name: str) -> Dict[str, Any]:
        """Parse parameters from action input text"""
        try:
            # Try JSON format first
            if input_text.startswith('{') and input_text.endswith('}'):
                return json.loads(input_text)
            
            # Try key=value format
            params = {}
            
            # Handle simple cases first
            if '=' not in input_text:
                # Single parameter without key - infer based on tool
                if tool_name in ['search_web', 'calculate']:
                    params['query' if tool_name == 'search_web' else 'expression'] = input_text.strip('"\'')
                return params
            
            # Parse key=value pairs with improved regex
            param_patterns = [
                r'(\w+)=(["\'])(.*?)\2',  # key="value" or key='value'
                r'(\w+)=([^,\s]+)',       # key=value (unquoted)
            ]
            
            for pattern in param_patterns:
                matches = re.findall(pattern, input_text)
                for match in matches:
                    if len(match) == 3:  # Quoted value
                        params[match[0]] = match[2]
                    elif len(match) == 2:  # Unquoted value
                        params[match[0]] = match[1]
            
            return params
            
        except Exception as e:
            logger.warning(f"Error parsing parameters '{input_text}': {e}")
            return {}

class JsonOutputParser(LLMOutputParser):
    """Parser for JSON format output"""
    
    def get_name(self) -> str:
        return "JsonOutputParser"
    
    def parse(self, llm_output: str) -> ParseResult:
        """Parse JSON format output"""
        try:
            # Try to extract JSON from the output
            json_match = re.search(r'\{.*\}', llm_output, re.DOTALL)
            if not json_match:
                return ParseResult(
                    is_final_answer=False,
                    error="No JSON found in output"
                )
            
            data = json.loads(json_match.group())
            
            # Check for final answer
            if data.get('final_answer'):
                return ParseResult(
                    is_final_answer=True,
                    final_answer=data['final_answer'],
                    thought=data.get('thought')
                )
            
            # Extract action
            if 'action' in data:
                action = ParsedAction(
                    tool_name=data['action'],
                    parameters=data.get('parameters', {}),
                    raw_text=llm_output,
                    confidence=0.95
                )
                
                return ParseResult(
                    is_final_answer=False,
                    action=action,
                    thought=data.get('thought')
                )
            
            return ParseResult(
                is_final_answer=False,
                error="No action or final_answer found in JSON"
            )
            
        except json.JSONDecodeError as e:
            logger.error(f"JSON parsing error: {e}")
            return ParseResult(
                is_final_answer=False,
                error=f"Invalid JSON: {e}"
            )
        except Exception as e:
            logger.error(f"Error parsing JSON output: {e}")
            return ParseResult(
                is_final_answer=False,
                error=f"Parsing error: {e}"
            )

class HybridParser(LLMOutputParser):
    """Parser that tries multiple strategies"""
    
    def __init__(self):
        self.parsers = [
            ReActTextParser(),
            JsonOutputParser()
        ]
    
    def get_name(self) -> str:
        return "HybridParser"
    
    def parse(self, llm_output: str) -> ParseResult:
        """Try multiple parsing strategies"""
        best_result = None
        best_confidence = 0.0
        
        for parser in self.parsers:
            try:
                result = parser.parse(llm_output)
                
                # If we got a successful parse, calculate confidence
                confidence = 0.0
                if result.is_final_answer and result.final_answer:
                    confidence = 0.9
                elif result.action and not result.error:
                    confidence = result.action.confidence
                elif result.error:
                    confidence = 0.0
                
                # Keep the best result
                if confidence > best_confidence:
                    best_result = result
                    best_confidence = confidence
                    
                # If we got a high-confidence result, use it
                if confidence >= 0.9:
                    logger.debug(f"High-confidence parse with {parser.get_name()}")
                    return result
                    
            except Exception as e:
                logger.warning(f"Parser {parser.get_name()} failed: {e}")
                continue
        
        # Return the best result we found, or an error if none worked
        if best_result:
            return best_result
        else:
            return ParseResult(
                is_final_answer=False,
                error="All parsing strategies failed"
            )

# Default parser instance
def get_default_parser() -> LLMOutputParser:
    """Get the default parser (hybrid approach)"""
    return HybridParser()

