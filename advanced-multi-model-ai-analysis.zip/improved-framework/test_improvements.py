#!/usr/bin/env python3
"""
Test the improved AI Agent Framework
Tests all architectural improvements and security fixes
"""

import sys
import os
sys.path.append('src')

def test_configuration():
    """Test the configuration system"""
    print("🔧 Testing Configuration System:")
    
    try:
        from src.config import AgentConfig, get_config
        
        # Test environment-based config
        os.environ["OPENROUTER_API_KEY"] = "test-key"
        os.environ["MAX_ITERATIONS"] = "15"
        os.environ["TEMPERATURE"] = "0.2"
        
        config = AgentConfig.from_env()
        print(f"  ✅ Config loaded: max_iterations={config.max_iterations}, temperature={config.temperature}")
        
        # Test validation
        config.validate()
        print("  ✅ Config validation passed")
        
        # Test dictionary conversion (should hide API key)
        config_dict = config.to_dict()
        assert config_dict['openrouter_api_key'] == '***REDACTED***'
        print("  ✅ API key properly redacted in dict conversion")
        
    except Exception as e:
        print(f"  ❌ Configuration test failed: {e}")
        return False
    
    return True

def test_parsers():
    """Test the output parsers"""
    print("\n📋 Testing Output Parsers:")
    
    try:
        from src.parsers import ReActTextParser, JsonOutputParser, HybridParser
        
        # Test ReAct parser
        react_parser = ReActTextParser()
        
        # Test final answer parsing
        final_answer_text = """
        Thought: I have enough information to answer.
        Final Answer: The result is 42.
        """
        
        result = react_parser.parse(final_answer_text)
        assert result.is_final_answer == True
        assert "42" in result.final_answer
        print("  ✅ ReAct parser correctly identified final answer")
        
        # Test action parsing
        action_text = """
        Thought: I need to calculate something.
        Action: calculate
        Action Input: expression="2 + 2"
        """
        
        result = react_parser.parse(action_text)
        assert result.is_final_answer == False
        assert result.action.tool_name == "calculate"
        assert result.action.parameters.get("expression") == "2 + 2"
        print("  ✅ ReAct parser correctly parsed action")
        
        # Test hybrid parser
        hybrid_parser = HybridParser()
        result = hybrid_parser.parse(action_text)
        assert result.action is not None
        print("  ✅ Hybrid parser working correctly")
        
    except Exception as e:
        print(f"  ❌ Parser test failed: {e}")
        return False
    
    return True

def test_tool_registry():
    """Test the improved tool registry"""
    print("\n🛠️ Testing Tool Registry:")
    
    try:
        from src.config import AgentConfig
        from src.improved_registry import ImprovedToolRegistry, create_tool_registry
        from src.tools.math_tools import SecureCalculatorTool
        
        # Create test config
        os.environ["OPENROUTER_API_KEY"] = "test-key"
        config = AgentConfig.from_env()
        
        # Test manual registry creation
        registry = ImprovedToolRegistry(config)
        calc_tool = SecureCalculatorTool(config)
        registry.register_tool(calc_tool)
        
        assert "calculate" in registry.tools
        print("  ✅ Tool registration working")
        
        # Test tool execution
        result = registry.execute_tool("calculate", expression="2 + 3")
        assert result.success == True
        assert "5" in result.result
        print("  ✅ Tool execution working")
        
        # Test tool disabling
        registry.disable_tool("calculate")
        result = registry.execute_tool("calculate", expression="1 + 1")
        assert result.success == False
        assert "disabled" in result.error
        print("  ✅ Tool disabling working")
        
        # Test factory function
        full_registry = create_tool_registry(config)
        enabled_tools = full_registry.get_enabled_tools()
        assert len(enabled_tools) > 0
        print(f"  ✅ Factory created registry with {len(enabled_tools)} tools")
        
    except Exception as e:
        print(f"  ❌ Tool registry test failed: {e}")
        return False
    
    return True

def test_security_fixes():
    """Test that security fixes are working"""
    print("\n🔒 Testing Security Fixes:")
    
    try:
        from src.tools.math_tools import SecureCalculatorTool
        from src.tools.file_tools import SecureFileWriteTool, SecureFileReadTool
        from src.config import AgentConfig
        
        os.environ["OPENROUTER_API_KEY"] = "test-key"
        config = AgentConfig.from_env()
        
        # Test secure calculator
        calc_tool = SecureCalculatorTool(config)
        
        # Should work
        result = calc_tool.execute(expression="2 + 3 * 4")
        assert result.success == True
        assert "14" in result.result
        print("  ✅ Safe math expressions work")
        
        # Should be blocked
        result = calc_tool.execute(expression="__import__('os').system('ls')")
        assert result.success == False
        print("  ✅ Dangerous expressions blocked")
        
        # Test secure file operations
        write_tool = SecureFileWriteTool(config)
        read_tool = SecureFileReadTool(config)
        
        # Normal operation should work
        result = write_tool.execute(filename="test.txt", content="Hello, World!")
        assert result.success == True
        print("  ✅ Secure file write working")
        
        result = read_tool.execute(filename="test.txt")
        assert result.success == True
        assert "Hello, World!" in result.result
        print("  ✅ Secure file read working")
        
        # Path traversal should be blocked
        result = write_tool.execute(filename="../../../etc/passwd", content="malicious")
        assert result.success == True  # Should succeed but write to sandbox
        assert "sandbox" in result.result
        print("  ✅ Path traversal protection working")
        
    except Exception as e:
        print(f"  ❌ Security test failed: {e}")
        return False
    
    return True

def test_improved_agent():
    """Test the improved agent (without API calls)"""
    print("\n🤖 Testing Improved Agent:")
    
    try:
        from src.improved_agent import ImprovedAIAgent, create_agent
        from src.config import AgentConfig
        
        # Test agent creation
        os.environ["OPENROUTER_API_KEY"] = "test-key"
        config = AgentConfig.from_env()
        
        agent = ImprovedAIAgent(config=config)
        print("  ✅ Agent created successfully")
        
        # Test agent info
        info = agent.get_agent_info()
        assert "model" in info
        assert "tools" in info
        assert "config" in info
        print("  ✅ Agent info retrieval working")
        
        # Test convenience function
        agent2 = create_agent(api_key="test-key-2")
        assert agent2 is not None
        print("  ✅ Convenience function working")
        
        print("  ⚠️  Full agent test requires API key - skipping LLM calls")
        
    except Exception as e:
        print(f"  ❌ Agent test failed: {e}")
        return False
    
    return True

def main():
    """Run all tests"""
    print("🧪 Testing Improved AI Agent Framework")
    print("=" * 60)
    
    tests = [
        test_configuration,
        test_parsers,
        test_tool_registry,
        test_security_fixes,
        test_improved_agent
    ]
    
    passed = 0
    total = len(tests)
    
    for test in tests:
        if test():
            passed += 1
    
    print(f"\n📊 Test Results: {passed}/{total} tests passed")
    
    if passed == total:
        print("🎉 All tests passed! The improved framework is working correctly.")
        print("\n🚀 Key Improvements Implemented:")
        print("  ✅ Security fixes (no more eval(), sandboxed files)")
        print("  ✅ Dependency injection architecture")
        print("  ✅ Configuration management system")
        print("  ✅ Enhanced error handling")
        print("  ✅ Modular tool system")
        print("  ✅ Improved output parsing")
        print("  ✅ Better logging and observability")
    else:
        print(f"⚠️  {total - passed} tests failed. Please check the errors above.")
    
    return passed == total

if __name__ == "__main__":
    success = main()
    sys.exit(0 if success else 1)

