#!/usr/bin/env python3
"""
Architecture Analyzer using DeepSeek V3 for performance analysis
"""

import os
from openai import OpenAI

def analyze_architecture(file_path: str, api_key: str):
    """Analyze architecture using DeepSeek V3"""
    client = OpenAI(
        base_url="https://openrouter.ai/api/v1",
        api_key=api_key
    )
    
    with open(file_path, 'r') as f:
        code = f.read()
    
    prompt = f"""
You are a senior software architect analyzing Python code for architectural improvements. 
Analyze this AI agent framework code:

```python
{code}
```

Focus on:
- Architecture patterns and design quality
- Separation of concerns
- Dependency management
- Error handling patterns
- Extensibility and maintainability
- Performance considerations
- Code organization

Provide specific, actionable recommendations in JSON format:
{{
    "architecture_issues": [
        {{
            "category": "coupling|cohesion|patterns|organization",
            "severity": "high|medium|low",
            "issue": "description",
            "current_code": "problematic code snippet",
            "recommendation": "specific improvement",
            "benefits": "why this helps"
        }}
    ],
    "performance_issues": [
        {{
            "category": "sync|memory|efficiency|scalability",
            "severity": "high|medium|low", 
            "issue": "description",
            "recommendation": "specific improvement"
        }}
    ],
    "design_improvements": [
        {{
            "pattern": "dependency_injection|factory|observer|strategy",
            "description": "what to implement",
            "benefits": "advantages"
        }}
    ],
    "next_iteration_priorities": [
        "priority 1 improvement",
        "priority 2 improvement", 
        "priority 3 improvement"
    ]
}}
"""
    
    print(f"🏗️ Analyzing architecture with Gemini 2.5 Flash...")
    
    response = client.chat.completions.create(
        model="google/gemini-2.5-flash",
        messages=[{"role": "user", "content": prompt}],
        temperature=0.1,
        max_tokens=3000
    )
    
    return response.choices[0].message.content

def main():
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        print("Error: OPENROUTER_API_KEY not set!")
        return
    
    file_path = "src/ai_agent_framework.py"
    
    if not os.path.exists(file_path):
        print(f"File not found: {file_path}")
        return
    
    try:
        result = analyze_architecture(file_path, api_key)
        print("\n" + "="*60)
        print("REAL AI ARCHITECTURE ANALYSIS (DeepSeek V3):")
        print("="*60)
        print(result)
        
        # Save results
        with open("architecture_analysis.txt", "w") as f:
            f.write(f"Architecture Analysis of {file_path}\n")
            f.write("="*50 + "\n\n")
            f.write("Analyzed by: DeepSeek V3 0324 (free)\n")
            f.write("Focus: Architecture, Performance, Design Patterns\n\n")
            f.write(result)
        
        print(f"\n✅ Architecture analysis saved to architecture_analysis.txt")
        
    except Exception as e:
        print(f"Error during analysis: {e}")

if __name__ == "__main__":
    main()

