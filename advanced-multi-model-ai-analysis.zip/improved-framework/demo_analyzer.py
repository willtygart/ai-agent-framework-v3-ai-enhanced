#!/usr/bin/env python3
"""
Demo Code Analysis Tool - Simulates OpenRouter Model Analysis
Shows what the analysis would look like with real API access
"""

import os
import json
from typing import Dict, List, Any
from dataclasses import dataclass

@dataclass
class CodeAnalysisResult:
    """Result from code analysis"""
    model_used: str
    analysis_type: str
    findings: List[Dict[str, Any]]
    recommendations: List[str]
    severity_score: int

class DemoCodeAnalyzer:
    """Demo analyzer that simulates real OpenRouter model analysis"""
    
    def __init__(self):
        self.models = {
            "security": "anthropic/claude-3.5-sonnet",
            "architecture": "anthropic/claude-3.5-sonnet", 
            "performance": "deepseek/deepseek-v3-0324:free",
            "best_practices": "google/gemini-2.5-flash"
        }
    
    def analyze_framework(self) -> Dict[str, List[CodeAnalysisResult]]:
        """Simulate comprehensive framework analysis"""
        
        # Simulate analysis of main framework file
        main_file_results = [
            # Security Analysis
            CodeAnalysisResult(
                model_used="anthropic/claude-3.5-sonnet",
                analysis_type="security",
                findings=[
                    {
                        "type": "security",
                        "severity": "critical",
                        "line_number": 85,
                        "issue": "Use of eval() function in calculate() method",
                        "explanation": "The eval() function can execute arbitrary code, creating a severe security vulnerability. An attacker could potentially execute malicious code by manipulating the expression parameter."
                    },
                    {
                        "type": "security", 
                        "severity": "high",
                        "line_number": 60,
                        "issue": "No input validation for file operations",
                        "explanation": "File read/write operations lack path validation, potentially allowing directory traversal attacks or access to sensitive files."
                    },
                    {
                        "type": "security",
                        "severity": "medium", 
                        "line_number": 120,
                        "issue": "API key exposure in error messages",
                        "explanation": "Error messages might inadvertently expose API keys or sensitive configuration data."
                    }
                ],
                recommendations=[
                    "Replace eval() with ast.literal_eval() or a safe mathematical expression parser",
                    "Add comprehensive input validation for all file operations",
                    "Implement secure error handling that doesn't expose sensitive data",
                    "Add rate limiting and input sanitization for all user inputs"
                ],
                severity_score=9
            ),
            
            # Architecture Analysis
            CodeAnalysisResult(
                model_used="anthropic/claude-3.5-sonnet",
                analysis_type="architecture",
                findings=[
                    {
                        "type": "architecture",
                        "severity": "high",
                        "line_number": None,
                        "issue": "Tight coupling between agent and tool execution",
                        "explanation": "The AIAgent class directly manages tool execution, making it difficult to test and extend. Better separation of concerns needed."
                    },
                    {
                        "type": "architecture",
                        "severity": "medium",
                        "line_number": 200,
                        "issue": "Hard-coded configuration values",
                        "explanation": "Configuration values like max_iterations are hard-coded, making the system inflexible."
                    },
                    {
                        "type": "architecture",
                        "severity": "medium",
                        "line_number": None,
                        "issue": "No dependency injection pattern",
                        "explanation": "Dependencies are created directly within classes, making testing and mocking difficult."
                    }
                ],
                recommendations=[
                    "Implement dependency injection for better testability",
                    "Create configuration management system",
                    "Add abstract interfaces for better modularity",
                    "Implement proper error recovery and retry mechanisms"
                ],
                severity_score=6
            ),
            
            # Performance Analysis  
            CodeAnalysisResult(
                model_used="deepseek/deepseek-v3-0324:free",
                analysis_type="performance",
                findings=[
                    {
                        "type": "performance",
                        "severity": "medium",
                        "line_number": 180,
                        "issue": "Synchronous API calls block execution",
                        "explanation": "All API calls are synchronous, preventing concurrent operations and reducing throughput."
                    },
                    {
                        "type": "performance",
                        "severity": "low",
                        "line_number": 150,
                        "issue": "No caching mechanism for repeated operations",
                        "explanation": "Repeated tool executions and model calls could benefit from intelligent caching."
                    }
                ],
                recommendations=[
                    "Implement async/await pattern for API calls",
                    "Add intelligent caching for tool results and model responses",
                    "Optimize prompt templates to reduce token usage",
                    "Implement connection pooling for better resource management"
                ],
                severity_score=4
            ),
            
            # Best Practices Analysis
            CodeAnalysisResult(
                model_used="google/gemini-2.5-flash",
                analysis_type="best_practices",
                findings=[
                    {
                        "type": "style",
                        "severity": "low",
                        "line_number": None,
                        "issue": "Inconsistent type hints usage",
                        "explanation": "Some functions lack type hints, reducing code clarity and IDE support."
                    },
                    {
                        "type": "style",
                        "severity": "low", 
                        "line_number": None,
                        "issue": "Missing docstrings for some methods",
                        "explanation": "Several methods lack comprehensive docstrings explaining parameters and return values."
                    }
                ],
                recommendations=[
                    "Add comprehensive type hints throughout the codebase",
                    "Implement comprehensive unit test suite",
                    "Add docstrings for all public methods and classes",
                    "Set up automated code formatting with black/flake8"
                ],
                severity_score=3
            )
        ]
        
        # Simulate analysis of demo file
        demo_file_results = [
            CodeAnalysisResult(
                model_used="anthropic/claude-3.5-sonnet",
                analysis_type="security",
                findings=[
                    {
                        "type": "security",
                        "severity": "low",
                        "line_number": 45,
                        "issue": "File operations without proper error handling",
                        "explanation": "File operations in todo management could fail silently or expose system information."
                    }
                ],
                recommendations=[
                    "Add proper exception handling for file operations",
                    "Validate file paths and permissions before operations"
                ],
                severity_score=2
            )
        ]
        
        return {
            "src/ai_agent_framework.py": main_file_results,
            "examples/interactive_demo.py": demo_file_results
        }
    
    def generate_improvement_report(self, results: Dict[str, List[CodeAnalysisResult]]) -> str:
        """Generate comprehensive improvement report"""
        report = []
        report.append("# AI Agent Framework - Code Analysis Report")
        report.append("*Generated using simulated OpenRouter model analysis*")
        report.append("=" * 60)
        report.append("")
        
        # Calculate summary statistics
        total_critical = 0
        total_high = 0
        total_medium = 0
        total_low = 0
        total_findings = 0
        
        for file_path, file_results in results.items():
            for result in file_results:
                for finding in result.findings:
                    severity = finding.get('severity', 'medium')
                    total_findings += 1
                    if severity == 'critical':
                        total_critical += 1
                    elif severity == 'high':
                        total_high += 1
                    elif severity == 'medium':
                        total_medium += 1
                    elif severity == 'low':
                        total_low += 1
        
        # Executive Summary
        report.append("## Executive Summary")
        report.append("")
        report.append(f"**Total Issues Found: {total_findings}**")
        report.append(f"- 🔴 Critical: {total_critical}")
        report.append(f"- 🟠 High: {total_high}")
        report.append(f"- 🟡 Medium: {total_medium}")
        report.append(f"- 🟢 Low: {total_low}")
        report.append("")
        
        if total_critical > 0:
            report.append("⚠️ **IMMEDIATE ACTION REQUIRED**: Critical security vulnerabilities detected!")
        elif total_high > 0:
            report.append("⚠️ **HIGH PRIORITY**: Significant issues require attention")
        else:
            report.append("✅ **GOOD**: No critical or high-priority issues detected")
        
        report.append("")
        report.append("### Models Used for Analysis:")
        for analysis_type, model in self.models.items():
            report.append(f"- **{analysis_type.title()}**: {model}")
        report.append("")
        report.append("---")
        report.append("")
        
        # Detailed Results
        for file_path, file_results in results.items():
            report.append(f"## 📁 {file_path}")
            report.append("")
            
            for result in file_results:
                report.append(f"### {result.analysis_type.title()} Analysis")
                report.append(f"**Model Used**: {result.model_used}")
                report.append(f"**Overall Severity Score**: {result.severity_score}/10")
                report.append("")
                
                if result.findings:
                    report.append("#### 🔍 Findings:")
                    for i, finding in enumerate(result.findings, 1):
                        severity = finding.get('severity', 'medium')
                        severity_emoji = {
                            'critical': '🔴',
                            'high': '🟠', 
                            'medium': '🟡',
                            'low': '🟢'
                        }.get(severity, '🟡')
                        
                        line_info = f" (Line {finding['line_number']})" if finding.get('line_number') else ""
                        report.append(f"{i}. {severity_emoji} **{severity.upper()}**{line_info}: {finding.get('issue', 'Unknown issue')}")
                        
                        if finding.get('explanation'):
                            report.append(f"   - *{finding['explanation']}*")
                        report.append("")
                
                if result.recommendations:
                    report.append("#### 💡 Recommendations:")
                    for i, rec in enumerate(result.recommendations, 1):
                        report.append(f"{i}. {rec}")
                    report.append("")
                
                report.append("---")
                report.append("")
        
        # Priority Action Items
        report.append("## 🎯 Priority Action Items")
        report.append("")
        
        if total_critical > 0:
            report.append("### 🔴 CRITICAL - Fix Immediately:")
            report.append("1. **Replace eval() function** - This is a severe security vulnerability")
            report.append("2. **Add input validation** - Prevent injection attacks")
            report.append("3. **Secure error handling** - Prevent information disclosure")
            report.append("")
        
        if total_high > 0:
            report.append("### 🟠 HIGH PRIORITY - Address Soon:")
            report.append("1. **Improve architecture** - Reduce coupling, add dependency injection")
            report.append("2. **Add configuration management** - Make system more flexible")
            report.append("3. **Implement proper error recovery** - Improve reliability")
            report.append("")
        
        report.append("### 🟡 MEDIUM PRIORITY - Plan for Next Iteration:")
        report.append("1. **Add async support** - Improve performance")
        report.append("2. **Implement caching** - Reduce API costs and latency")
        report.append("3. **Add comprehensive testing** - Improve code quality")
        report.append("")
        
        report.append("### 🟢 LOW PRIORITY - Code Quality Improvements:")
        report.append("1. **Add type hints** - Improve code clarity")
        report.append("2. **Improve documentation** - Better developer experience")
        report.append("3. **Set up automated formatting** - Consistent code style")
        report.append("")
        
        return "\n".join(report)

def main():
    """Run demo analysis"""
    print("🔍 AI Agent Framework - Demo Code Analysis")
    print("=" * 50)
    print("This demo simulates what OpenRouter model analysis would find.")
    print("For real analysis, set OPENROUTER_API_KEY environment variable.")
    print("")
    
    analyzer = DemoCodeAnalyzer()
    
    print("📊 Running simulated analysis with top models:")
    for analysis_type, model in analyzer.models.items():
        print(f"  - {analysis_type}: {model}")
    print("")
    
    # Run simulated analysis
    results = analyzer.analyze_framework()
    
    # Generate report
    report = analyzer.generate_improvement_report(results)
    
    # Save report
    with open("demo_analysis_report.md", "w") as f:
        f.write(report)
    
    print("✅ Demo analysis complete! Report saved to demo_analysis_report.md")
    print("")
    
    # Print key findings
    total_critical = 0
    total_high = 0
    for file_results in results.values():
        for result in file_results:
            for finding in result.findings:
                if finding.get('severity') == 'critical':
                    total_critical += 1
                elif finding.get('severity') == 'high':
                    total_high += 1
    
    print("🎯 Key Findings Summary:")
    print(f"  - Critical security issues: {total_critical}")
    print(f"  - High priority issues: {total_high}")
    
    if total_critical > 0:
        print("")
        print("⚠️  CRITICAL: eval() function detected - severe security risk!")
        print("   This must be fixed before any production use.")
    
    return results

if __name__ == "__main__":
    main()

