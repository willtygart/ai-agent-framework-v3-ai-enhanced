#!/usr/bin/env python3
"""
Interactive AI Agent Demo
Demonstrates how to use the AI Agent Framework with OpenRouter models
"""

import os
import sys
sys.path.append(os.path.join(os.path.dirname(__file__), '..', 'src'))

from ai_agent_framework import AIAgent, tool_registry, ToolResult

# ============================================================================
# EXTENDED TOOLS FOR DEMONSTRATION
# ============================================================================

def create_story(topic: str, style: str = "adventure") -> str:
    """Create a short story about a given topic"""
    styles = {
        "adventure": "An exciting adventure story filled with danger and discovery",
        "mystery": "A mysterious tale with twists and unexpected revelations", 
        "comedy": "A humorous story that will make you laugh",
        "drama": "A dramatic story with deep emotions and character development",
        "sci-fi": "A science fiction story set in the future with advanced technology"
    }
    
    style_desc = styles.get(style, "An engaging story")
    
    story = f"""
{style_desc} about {topic}:

Once upon a time, in a world not so different from our own, there lived a character whose life was about to change forever because of {topic}. 

The story begins when our protagonist first encounters {topic}, setting off a chain of events that would test their courage, wisdom, and determination. Through trials and tribulations, they learn valuable lessons about life, friendship, and the power of believing in oneself.

In the end, {topic} becomes not just a part of their story, but the key to understanding their true purpose in life.

The End.
"""
    return story.strip()

def analyze_text(text: str, analysis_type: str = "sentiment") -> str:
    """Analyze text for various properties"""
    if analysis_type == "sentiment":
        # Simple sentiment analysis
        positive_words = ["good", "great", "excellent", "amazing", "wonderful", "fantastic", "love", "happy"]
        negative_words = ["bad", "terrible", "awful", "hate", "sad", "angry", "disappointed"]
        
        text_lower = text.lower()
        pos_count = sum(1 for word in positive_words if word in text_lower)
        neg_count = sum(1 for word in negative_words if word in text_lower)
        
        if pos_count > neg_count:
            sentiment = "Positive"
        elif neg_count > pos_count:
            sentiment = "Negative"
        else:
            sentiment = "Neutral"
        
        return f"Sentiment Analysis: {sentiment} (Positive words: {pos_count}, Negative words: {neg_count})"
    
    elif analysis_type == "stats":
        words = text.split()
        sentences = text.split('.')
        characters = len(text)
        
        return f"Text Statistics: {len(words)} words, {len(sentences)} sentences, {characters} characters"
    
    else:
        return f"Unknown analysis type: {analysis_type}"

def manage_todo_list(action: str, item: str = "") -> str:
    """Manage a simple todo list"""
    todo_file = "todo_list.txt"
    
    if action == "add":
        if not item:
            return "Error: No item provided to add"
        
        try:
            with open(todo_file, "a") as f:
                f.write(f"- {item}\n")
            return f"Added '{item}' to todo list"
        except Exception as e:
            return f"Error adding item: {e}"
    
    elif action == "list":
        try:
            if os.path.exists(todo_file):
                with open(todo_file, "r") as f:
                    content = f.read().strip()
                return f"Todo List:\n{content}" if content else "Todo list is empty"
            else:
                return "Todo list doesn't exist yet"
        except Exception as e:
            return f"Error reading todo list: {e}"
    
    elif action == "clear":
        try:
            if os.path.exists(todo_file):
                os.remove(todo_file)
            return "Todo list cleared"
        except Exception as e:
            return f"Error clearing todo list: {e}"
    
    else:
        return f"Unknown action: {action}. Use 'add', 'list', or 'clear'"

def get_model_recommendation(use_case: str) -> str:
    """Recommend OpenRouter models for specific use cases"""
    recommendations = {
        "programming": [
            "anthropic/claude-3.5-sonnet - Best overall for coding tasks",
            "deepseek/deepseek-v3-0324:free - Excellent free option for programming",
            "google/gemini-2.5-flash - Fast and capable for code generation"
        ],
        "writing": [
            "anthropic/claude-3.5-sonnet - Superior writing capabilities",
            "openai/gpt-4.1 - Excellent for creative writing",
            "google/gemini-2.5-pro - Great for long-form content"
        ],
        "analysis": [
            "anthropic/claude-3.5-sonnet - Best for complex analysis",
            "google/gemini-2.5-pro - Strong analytical capabilities",
            "deepseek/deepseek-v3-0324 - Good for data analysis"
        ],
        "free": [
            "deepseek/deepseek-v3-0324:free - Top free model overall",
            "deepseek/deepseek-r1-0528:free - Free reasoning model",
            "google/gemini-2.5-flash-lite-preview - Fast free option"
        ],
        "reasoning": [
            "deepseek/deepseek-r1-0528:free - Specialized reasoning model",
            "anthropic/claude-3.7-sonnet:thinking - Thinking model",
            "anthropic/claude-3.5-sonnet - Excellent reasoning capabilities"
        ]
    }
    
    if use_case in recommendations:
        result = f"Recommended models for {use_case}:\n"
        for i, model in enumerate(recommendations[use_case], 1):
            result += f"{i}. {model}\n"
        return result
    else:
        available_cases = ", ".join(recommendations.keys())
        return f"Unknown use case. Available options: {available_cases}"

# Register extended tools
tool_registry.register_tool("create_story", create_story,
    "create_story(topic: str, style: str = 'adventure') -> str - Create a short story about a topic in a specific style")

tool_registry.register_tool("analyze_text", analyze_text,
    "analyze_text(text: str, analysis_type: str = 'sentiment') -> str - Analyze text for sentiment or statistics")

tool_registry.register_tool("manage_todo_list", manage_todo_list,
    "manage_todo_list(action: str, item: str = '') -> str - Manage todo list (actions: add, list, clear)")

tool_registry.register_tool("get_model_recommendation", get_model_recommendation,
    "get_model_recommendation(use_case: str) -> str - Get OpenRouter model recommendations for specific use cases")

# ============================================================================
# INTERACTIVE DEMO APPLICATION
# ============================================================================

class InteractiveAgent:
    """Interactive demo application for the AI Agent"""
    
    def __init__(self):
        self.agent = None
        self.available_models = [
            "anthropic/claude-3.5-sonnet",
            "google/gemini-2.5-flash", 
            "deepseek/deepseek-v3-0324:free",
            "openai/gpt-4.1-mini",
            "google/gemini-2.5-pro"
        ]
    
    def setup_agent(self):
        """Setup the AI agent with user's choice of model"""
        print("🤖 AI Agent Framework Demo")
        print("=" * 40)
        
        # Check API key
        api_key = os.getenv("OPENROUTER_API_KEY")
        if not api_key:
            print("❌ Error: OPENROUTER_API_KEY environment variable not set!")
            print("Please set your OpenRouter API key:")
            print("export OPENROUTER_API_KEY='your-api-key-here'")
            return False
        
        # Model selection
        print("\n📋 Available Models:")
        for i, model in enumerate(self.available_models, 1):
            print(f"{i}. {model}")
        
        while True:
            try:
                choice = input(f"\nSelect a model (1-{len(self.available_models)}) or press Enter for default: ").strip()
                
                if not choice:
                    selected_model = self.available_models[0]
                    break
                
                choice_idx = int(choice) - 1
                if 0 <= choice_idx < len(self.available_models):
                    selected_model = self.available_models[choice_idx]
                    break
                else:
                    print("Invalid choice. Please try again.")
            except ValueError:
                print("Please enter a valid number.")
        
        print(f"\n✅ Selected model: {selected_model}")
        self.agent = AIAgent(model_name=selected_model, api_key=api_key)
        return True
    
    def show_examples(self):
        """Show example requests"""
        examples = [
            "What are the best free OpenRouter models for programming?",
            "Create an adventure story about a magical forest and save it to a file",
            "Add 'Learn Python' to my todo list and then show me the full list",
            "Calculate 25 * 17 + 83 and analyze the sentiment of the result",
            "Recommend models for writing tasks and explain why",
            "What time is it and create a mystery story about time travel"
        ]
        
        print("\n💡 Example requests you can try:")
        for i, example in enumerate(examples, 1):
            print(f"{i}. {example}")
    
    def run_interactive_session(self):
        """Run the interactive session"""
        if not self.setup_agent():
            return
        
        self.show_examples()
        
        print("\n🚀 Agent is ready! Type your requests below.")
        print("Type 'examples' to see examples again, 'quit' to exit.\n")
        
        while True:
            try:
                user_input = input("👤 You: ").strip()
                
                if user_input.lower() in ['quit', 'exit', 'q']:
                    print("👋 Goodbye!")
                    break
                
                if user_input.lower() == 'examples':
                    self.show_examples()
                    continue
                
                if not user_input:
                    print("Please enter a request.")
                    continue
                
                print(f"\n🤖 Agent is thinking...")
                result = self.agent.run(user_input)
                print(f"\n🤖 Agent: {result}\n")
                
            except KeyboardInterrupt:
                print("\n\n👋 Goodbye!")
                break
            except Exception as e:
                print(f"\n❌ Error: {e}\n")

# ============================================================================
# BATCH TESTING FUNCTION
# ============================================================================

def run_batch_tests():
    """Run a series of tests to demonstrate the agent's capabilities"""
    
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        print("❌ Error: OPENROUTER_API_KEY not set. Cannot run tests.")
        return
    
    print("🧪 Running Batch Tests")
    print("=" * 40)
    
    agent = AIAgent(model_name="anthropic/claude-3.5-sonnet", api_key=api_key)
    
    test_cases = [
        {
            "name": "Model Recommendation",
            "request": "What are the top 3 free OpenRouter models and their strengths?"
        },
        {
            "name": "File Operations",
            "request": "Create a simple Python hello world program and save it to hello.py"
        },
        {
            "name": "Math and Analysis",
            "request": "Calculate 15 * 23 + 47 - 12 and analyze the sentiment of the number"
        },
        {
            "name": "Creative Task",
            "request": "Create a sci-fi story about AI agents and save it to story.txt"
        },
        {
            "name": "Todo Management",
            "request": "Add 'Test AI agent' to my todo list and then show me the current list"
        }
    ]
    
    for i, test in enumerate(test_cases, 1):
        print(f"\n📝 Test {i}: {test['name']}")
        print(f"Request: {test['request']}")
        print("-" * 40)
        
        try:
            result = agent.run(test['request'])
            print(f"✅ Result: {result}")
        except Exception as e:
            print(f"❌ Error: {e}")
        
        print()

# ============================================================================
# MAIN FUNCTION
# ============================================================================

def main():
    """Main function to run the application"""
    
    if len(sys.argv) > 1:
        if sys.argv[1] == "test":
            run_batch_tests()
        elif sys.argv[1] == "interactive":
            app = InteractiveAgent()
            app.run_interactive_session()
        else:
            print("Usage: python interactive_demo.py [test|interactive]")
    else:
        # Default to interactive mode
        app = InteractiveAgent()
        app.run_interactive_session()

if __name__ == "__main__":
    main()

