#!/usr/bin/env python3
"""
Security Fixes for AI Agent Framework
Based on real Claude Sonnet analysis
"""

import ast
import os
import re
import operator
from pathlib import Path
from typing import Union

# Safe math operations mapping
SAFE_OPERATORS = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.Pow: operator.pow,
    ast.Mod: operator.mod,
    ast.USub: operator.neg,
    ast.UAdd: operator.pos,
}

class SafeMathEvaluator:
    """Safe mathematical expression evaluator to replace eval()"""
    
    def __init__(self):
        self.allowed_names = {
            'pi': 3.141592653589793,
            'e': 2.718281828459045,
        }
    
    def evaluate(self, expression: str) -> Union[float, int]:
        """Safely evaluate mathematical expressions"""
        try:
            # Parse the expression into an AST
            node = ast.parse(expression, mode='eval')
            return self._eval_node(node.body)
        except Exception as e:
            raise ValueError(f"Invalid mathematical expression: {e}")
    
    def _eval_node(self, node):
        """Recursively evaluate AST nodes"""
        if isinstance(node, ast.Constant):  # Numbers
            return node.value
        elif isinstance(node, ast.Name):  # Variables like pi, e
            if node.id in self.allowed_names:
                return self.allowed_names[node.id]
            else:
                raise ValueError(f"Unknown variable: {node.id}")
        elif isinstance(node, ast.BinOp):  # Binary operations
            left = self._eval_node(node.left)
            right = self._eval_node(node.right)
            op_type = type(node.op)
            if op_type in SAFE_OPERATORS:
                return SAFE_OPERATORS[op_type](left, right)
            else:
                raise ValueError(f"Unsupported operation: {op_type}")
        elif isinstance(node, ast.UnaryOp):  # Unary operations
            operand = self._eval_node(node.operand)
            op_type = type(node.op)
            if op_type in SAFE_OPERATORS:
                return SAFE_OPERATORS[op_type](operand)
            else:
                raise ValueError(f"Unsupported unary operation: {op_type}")
        else:
            raise ValueError(f"Unsupported node type: {type(node)}")

class SecureFileHandler:
    """Secure file operations with path validation"""
    
    def __init__(self, allowed_base_dir: str = "./sandbox"):
        """Initialize with allowed base directory"""
        self.allowed_base_dir = os.path.abspath(allowed_base_dir)
        # Create sandbox directory if it doesn't exist
        os.makedirs(self.allowed_base_dir, exist_ok=True)
    
    def _validate_path(self, filename: str) -> str:
        """Validate file path to prevent directory traversal"""
        # Resolve the absolute path
        abs_path = os.path.abspath(filename)
        
        # Check if the path is within the allowed directory
        if not abs_path.startswith(self.allowed_base_dir):
            # If not in sandbox, put it in sandbox
            safe_filename = os.path.basename(filename)
            abs_path = os.path.join(self.allowed_base_dir, safe_filename)
        
        return abs_path
    
    def _validate_file_size(self, filepath: str, max_size_mb: int = 10):
        """Validate file size"""
        if os.path.exists(filepath):
            size_mb = os.path.getsize(filepath) / (1024 * 1024)
            if size_mb > max_size_mb:
                raise ValueError(f"File too large: {size_mb:.1f}MB (max: {max_size_mb}MB)")
    
    def write_file(self, filename: str, content: str, max_size_mb: int = 10) -> str:
        """Securely write content to a file"""
        try:
            # Validate and sanitize the path
            safe_path = self._validate_path(filename)
            
            # Check content size
            content_size_mb = len(content.encode('utf-8')) / (1024 * 1024)
            if content_size_mb > max_size_mb:
                return f"Error: Content too large ({content_size_mb:.1f}MB, max: {max_size_mb}MB)"
            
            # Write the file
            with open(safe_path, 'w', encoding='utf-8') as f:
                f.write(content)
            
            return f"Successfully wrote content to {os.path.basename(safe_path)}"
        except Exception as e:
            return f"Error writing to file: {e}"
    
    def read_file(self, filename: str, max_size_mb: int = 10) -> str:
        """Securely read content from a file"""
        try:
            # Validate and sanitize the path
            safe_path = self._validate_path(filename)
            
            # Check if file exists
            if not os.path.exists(safe_path):
                return f"Error: File '{os.path.basename(filename)}' not found"
            
            # Validate file size
            self._validate_file_size(safe_path, max_size_mb)
            
            # Read the file
            with open(safe_path, 'r', encoding='utf-8') as f:
                content = f.read()
            
            return f"File content:\n{content}"
        except Exception as e:
            return f"Error reading file: {e}"

class InputValidator:
    """Input validation and sanitization"""
    
    @staticmethod
    def sanitize_user_input(user_input: str, max_length: int = 10000) -> str:
        """Sanitize user input"""
        if len(user_input) > max_length:
            raise ValueError(f"Input too long: {len(user_input)} chars (max: {max_length})")
        
        # Remove potentially dangerous patterns
        dangerous_patterns = [
            r'__import__',
            r'exec\s*\(',
            r'eval\s*\(',
            r'open\s*\(',
            r'file\s*\(',
            r'input\s*\(',
            r'raw_input\s*\(',
        ]
        
        for pattern in dangerous_patterns:
            if re.search(pattern, user_input, re.IGNORECASE):
                raise ValueError(f"Potentially dangerous input detected")
        
        return user_input.strip()
    
    @staticmethod
    def validate_math_expression(expression: str) -> str:
        """Validate mathematical expression"""
        # Only allow safe characters for math
        allowed_chars = set('0123456789+-*/()., pie')
        if not all(c in allowed_chars for c in expression.replace(' ', '')):
            raise ValueError("Invalid characters in mathematical expression")
        
        # Check for reasonable length
        if len(expression) > 200:
            raise ValueError("Mathematical expression too long")
        
        return expression.strip()

# Updated secure functions
def secure_calculate(expression: str) -> str:
    """Safely calculate mathematical expressions without eval()"""
    try:
        # Validate the expression
        clean_expr = InputValidator.validate_math_expression(expression)
        
        # Use safe evaluator instead of eval()
        evaluator = SafeMathEvaluator()
        result = evaluator.evaluate(clean_expr)
        
        return f"Result: {result}"
    except Exception as e:
        return f"Error calculating: {e}"

# Initialize secure file handler
secure_file_handler = SecureFileHandler()

def secure_write_file(filename: str, content: str) -> str:
    """Securely write content to a file"""
    return secure_file_handler.write_file(filename, content)

def secure_read_file(filename: str) -> str:
    """Securely read content from a file"""
    return secure_file_handler.read_file(filename)

def test_security_fixes():
    """Test the security fixes"""
    print("🔒 Testing Security Fixes")
    print("=" * 40)
    
    # Test safe math evaluation
    print("\n1. Testing Safe Math Evaluation:")
    test_expressions = [
        "2 + 3 * 4",
        "10 / 2 - 1", 
        "2 ** 3",
        "pi * 2",
        "sqrt(16)",  # This should fail safely
        "__import__('os').system('ls')"  # This should fail safely
    ]
    
    for expr in test_expressions:
        try:
            result = secure_calculate(expr)
            print(f"  '{expr}' -> {result}")
        except Exception as e:
            print(f"  '{expr}' -> ERROR: {e}")
    
    # Test secure file operations
    print("\n2. Testing Secure File Operations:")
    
    # Test normal file operation
    result = secure_write_file("test.txt", "Hello, secure world!")
    print(f"  Write test: {result}")
    
    result = secure_read_file("test.txt")
    print(f"  Read test: {result[:50]}...")
    
    # Test path traversal protection
    result = secure_write_file("../../../etc/passwd", "malicious content")
    print(f"  Path traversal test: {result}")
    
    # Test file size limits
    large_content = "x" * (11 * 1024 * 1024)  # 11MB
    result = secure_write_file("large.txt", large_content)
    print(f"  Large file test: {result}")
    
    print("\n✅ Security fixes tested!")

if __name__ == "__main__":
    test_security_fixes()

