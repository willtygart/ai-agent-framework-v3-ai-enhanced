#!/usr/bin/env python3
"""
Advanced Multi-Model AI Orchestration System
Coordinates 6 specialized OpenRouter models across 5 rounds of iterative improvement
"""

import asyncio
import json
import logging
import time
from dataclasses import dataclass, asdict
from typing import Dict, List, Optional, Any, Tuple
from enum import Enum
from openai import AsyncOpenAI
import os

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

class ModelRole(Enum):
    """Specialized roles for each AI model"""
    CODING_PRIMARY = "coding_primary"
    CODING_SECONDARY = "coding_secondary"
    UX_PRIMARY = "ux_primary"
    UX_SECONDARY = "ux_secondary"
    SYNTHESIS = "synthesis"
    GAP_ANALYSIS = "gap_analysis"

@dataclass
class ModelConfig:
    """Configuration for each AI model"""
    name: str
    provider: str
    model_id: str
    role: ModelRole
    specialization: str
    focus_areas: List[str]
    max_tokens: int = 4000
    temperature: float = 0.1

@dataclass
class AnalysisResult:
    """Result from a single model analysis"""
    model_name: str
    role: ModelRole
    round_number: int
    analysis_type: str
    findings: str
    recommendations: List[str]
    priority_score: int  # 1-10
    confidence_score: float  # 0.0-1.0
    execution_time: float
    token_usage: int

@dataclass
class RoundSummary:
    """Summary of a complete analysis round"""
    round_number: int
    total_models: int
    total_findings: int
    high_priority_items: List[str]
    consensus_items: List[str]
    conflicting_opinions: List[str]
    synthesis_summary: str
    identified_gaps: List[str]
    next_round_focus: List[str]

class MultiModelOrchestrator:
    """Orchestrates multiple AI models for comprehensive code analysis"""
    
    def __init__(self, api_key: str):
        """Initialize the orchestrator with API key"""
        self.api_key = api_key
        self.client = AsyncOpenAI(
            base_url="https://openrouter.ai/api/v1",
            api_key=api_key
        )
        
        # Initialize model configurations based on July 2025 rankings
        self.models = {
            ModelRole.CODING_PRIMARY: ModelConfig(
                name="Claude Sonnet 4",
                provider="anthropic",
                model_id="anthropic/claude-sonnet-4",
                role=ModelRole.CODING_PRIMARY,
                specialization="Security and Architecture Analysis",
                focus_areas=["security vulnerabilities", "architecture patterns", "code quality", "best practices"]
            ),
            ModelRole.CODING_SECONDARY: ModelConfig(
                name="DeepSeek V3 0324",
                provider="deepseek",
                model_id="deepseek/deepseek-v3-0324",
                role=ModelRole.CODING_SECONDARY,
                specialization="Performance and Algorithmic Analysis",
                focus_areas=["performance optimization", "algorithms", "efficiency", "scalability"]
            ),
            ModelRole.UX_PRIMARY: ModelConfig(
                name="Gemini 2.5 Flash",
                provider="google",
                model_id="google/gemini-2.5-flash",
                role=ModelRole.UX_PRIMARY,
                specialization="User Interface and Experience",
                focus_areas=["user interface design", "workflow analysis", "accessibility", "usability"]
            ),
            ModelRole.UX_SECONDARY: ModelConfig(
                name="Gemini 2.5 Pro",
                provider="google", 
                model_id="google/gemini-2.5-pro",
                role=ModelRole.UX_SECONDARY,
                specialization="User Journey and Interaction Design",
                focus_areas=["user journey mapping", "interaction design", "user psychology", "pain points"]
            ),
            ModelRole.SYNTHESIS: ModelConfig(
                name="Gemini 2.0 Flash",
                provider="google",
                model_id="google/gemini-2.0-flash",
                role=ModelRole.SYNTHESIS,
                specialization="Synthesis and Coordination",
                focus_areas=["team coordination", "synthesis", "comprehensive reporting", "pattern identification"]
            ),
            ModelRole.GAP_ANALYSIS: ModelConfig(
                name="Claude 3.7 Sonnet",
                provider="anthropic",
                model_id="anthropic/claude-3.7-sonnet",
                role=ModelRole.GAP_ANALYSIS,
                specialization="Gap Identification and Critical Analysis",
                focus_areas=["gap identification", "edge cases", "critical analysis", "assumption questioning"]
            )
        }
        
        # Analysis history
        self.analysis_history: List[AnalysisResult] = []
        self.round_summaries: List[RoundSummary] = []
        self.current_round = 0
        
        logger.info(f"Initialized MultiModelOrchestrator with {len(self.models)} specialized models")
    
    async def analyze_code(self, code_content: str, file_path: str, round_number: int) -> List[AnalysisResult]:
        """Analyze code using all 6 models in parallel"""
        logger.info(f"Starting Round {round_number} analysis with 6 models")
        
        # Create analysis tasks for all models
        tasks = []
        for role, config in self.models.items():
            task = self._analyze_with_model(config, code_content, file_path, round_number)
            tasks.append(task)
        
        # Execute all analyses in parallel
        start_time = time.time()
        results = await asyncio.gather(*tasks, return_exceptions=True)
        total_time = time.time() - start_time
        
        # Process results and handle exceptions
        valid_results = []
        for i, result in enumerate(results):
            if isinstance(result, Exception):
                logger.error(f"Model {list(self.models.keys())[i]} failed: {result}")
            else:
                valid_results.append(result)
                self.analysis_history.append(result)
        
        logger.info(f"Round {round_number} completed in {total_time:.2f}s with {len(valid_results)} successful analyses")
        return valid_results
    
    async def _analyze_with_model(self, config: ModelConfig, code_content: str, 
                                file_path: str, round_number: int) -> AnalysisResult:
        """Analyze code with a specific model"""
        start_time = time.time()
        
        # Get previous round context
        previous_context = self._get_previous_context(config.role, round_number)
        
        # Create specialized prompt based on model role
        prompt = self._create_specialized_prompt(config, code_content, file_path, 
                                               round_number, previous_context)
        
        try:
            # Call the model
            response = await self.client.chat.completions.create(
                model=config.model_id,
                messages=[{"role": "user", "content": prompt}],
                temperature=config.temperature,
                max_tokens=config.max_tokens
            )
            
            execution_time = time.time() - start_time
            content = response.choices[0].message.content
            
            # Parse the structured response
            analysis_data = self._parse_model_response(content, config.role)
            
            result = AnalysisResult(
                model_name=config.name,
                role=config.role,
                round_number=round_number,
                analysis_type=config.specialization,
                findings=analysis_data.get("findings", ""),
                recommendations=analysis_data.get("recommendations", []),
                priority_score=analysis_data.get("priority_score", 5),
                confidence_score=analysis_data.get("confidence_score", 0.8),
                execution_time=execution_time,
                token_usage=response.usage.total_tokens if response.usage else 0
            )
            
            logger.info(f"{config.name} completed analysis in {execution_time:.2f}s")
            return result
            
        except Exception as e:
            logger.error(f"Error analyzing with {config.name}: {e}")
            # Return error result
            return AnalysisResult(
                model_name=config.name,
                role=config.role,
                round_number=round_number,
                analysis_type=config.specialization,
                findings=f"Analysis failed: {e}",
                recommendations=[],
                priority_score=1,
                confidence_score=0.0,
                execution_time=time.time() - start_time,
                token_usage=0
            )
    
    def _create_specialized_prompt(self, config: ModelConfig, code_content: str, 
                                 file_path: str, round_number: int, previous_context: str) -> str:
        """Create specialized prompt based on model role"""
        
        base_context = f"""
You are {config.name}, a specialized AI expert in {config.specialization}.
You are part of a 6-model AI team analyzing and improving an AI agent framework.

Your role: {config.role.value}
Your specialization: {config.specialization}
Your focus areas: {', '.join(config.focus_areas)}

Current analysis round: {round_number}/5
File being analyzed: {file_path}

{previous_context}

Please analyze the following code and provide structured feedback in JSON format:
{{
    "findings": "Your detailed analysis findings",
    "recommendations": ["Specific recommendation 1", "Specific recommendation 2", ...],
    "priority_score": 1-10 (10 = critical, 1 = minor),
    "confidence_score": 0.0-1.0,
    "implementation_notes": "How to implement your recommendations",
    "related_areas": ["Other areas that might be affected"]
}}

Code to analyze:
```python
{code_content}
```
"""
        
        # Add role-specific instructions
        if config.role == ModelRole.CODING_PRIMARY:
            base_context += """
Focus on:
- Security vulnerabilities and exploits
- Architecture patterns and design quality
- Code maintainability and readability
- Best practices compliance
- Critical bugs and issues
"""
        elif config.role == ModelRole.CODING_SECONDARY:
            base_context += """
Focus on:
- Performance bottlenecks and optimizations
- Algorithmic complexity and efficiency
- Memory usage and resource management
- Scalability considerations
- Mathematical accuracy
"""
        elif config.role == ModelRole.UX_PRIMARY:
            base_context += """
Focus on:
- User interface design and usability
- User workflow and interaction patterns
- Accessibility and inclusive design
- Error handling from user perspective
- API usability and developer experience
"""
        elif config.role == ModelRole.UX_SECONDARY:
            base_context += """
Focus on:
- User journey mapping and flow
- User psychology and behavior
- Pain points and friction areas
- Onboarding and learning curve
- User feedback and error messages
"""
        elif config.role == ModelRole.SYNTHESIS:
            base_context += """
Your special role: Synthesize findings from other models.
Focus on:
- Identifying common themes across analyses
- Resolving conflicts between recommendations
- Creating comprehensive improvement roadmap
- Prioritizing recommendations by impact
- Coordinating implementation strategy
"""
        elif config.role == ModelRole.GAP_ANALYSIS:
            base_context += """
Your special role: Find what others missed.
Focus on:
- Edge cases and corner scenarios
- Assumptions that might be wrong
- Missing error handling
- Overlooked security issues
- Unstated requirements or implications
"""
        
        return base_context
    
    def _get_previous_context(self, role: ModelRole, round_number: int) -> str:
        """Get context from previous rounds for this model role"""
        if round_number <= 1:
            return "This is the first analysis round."
        
        previous_results = [r for r in self.analysis_history 
                          if r.role == role and r.round_number < round_number]
        
        if not previous_results:
            return "No previous analysis from this model."
        
        latest = previous_results[-1]
        context = f"""
Previous analysis from {latest.model_name}:
- Findings: {latest.findings[:200]}...
- Top recommendations: {latest.recommendations[:3]}
- Priority score: {latest.priority_score}/10

Build upon these previous findings in your current analysis.
"""
        return context
    
    def _parse_model_response(self, content: str, role: ModelRole) -> Dict[str, Any]:
        """Parse structured JSON response from model"""
        try:
            # Try to extract JSON from the response
            json_start = content.find('{')
            json_end = content.rfind('}') + 1
            
            if json_start >= 0 and json_end > json_start:
                json_str = content[json_start:json_end]
                return json.loads(json_str)
            else:
                # Fallback parsing if JSON not found
                return {
                    "findings": content,
                    "recommendations": ["Review the analysis manually"],
                    "priority_score": 5,
                    "confidence_score": 0.7
                }
        except json.JSONDecodeError:
            logger.warning(f"Failed to parse JSON from {role.value}, using fallback")
            return {
                "findings": content,
                "recommendations": ["Review the analysis manually"],
                "priority_score": 5,
                "confidence_score": 0.7
            }
    
    async def synthesize_round(self, round_results: List[AnalysisResult]) -> RoundSummary:
        """Synthesize results from all models in a round"""
        logger.info(f"Synthesizing Round {round_results[0].round_number} results")
        
        # Extract synthesis model result
        synthesis_result = next((r for r in round_results if r.role == ModelRole.SYNTHESIS), None)
        gap_analysis_result = next((r for r in round_results if r.role == ModelRole.GAP_ANALYSIS), None)
        
        # Analyze consensus and conflicts
        all_recommendations = []
        for result in round_results:
            all_recommendations.extend(result.recommendations)
        
        # Find high priority items
        high_priority = [r for r in round_results if r.priority_score >= 8]
        
        # Create round summary
        summary = RoundSummary(
            round_number=round_results[0].round_number,
            total_models=len(round_results),
            total_findings=len([r for r in round_results if r.findings]),
            high_priority_items=[r.findings for r in high_priority],
            consensus_items=self._find_consensus_items(round_results),
            conflicting_opinions=self._find_conflicts(round_results),
            synthesis_summary=synthesis_result.findings if synthesis_result else "No synthesis available",
            identified_gaps=gap_analysis_result.recommendations if gap_analysis_result else [],
            next_round_focus=self._determine_next_focus(round_results)
        )
        
        self.round_summaries.append(summary)
        return summary
    
    def _find_consensus_items(self, results: List[AnalysisResult]) -> List[str]:
        """Find recommendations that appear across multiple models"""
        recommendation_counts = {}
        for result in results:
            for rec in result.recommendations:
                rec_lower = rec.lower()
                recommendation_counts[rec_lower] = recommendation_counts.get(rec_lower, 0) + 1
        
        # Return items mentioned by 2+ models
        consensus = [rec for rec, count in recommendation_counts.items() if count >= 2]
        return consensus[:5]  # Top 5 consensus items
    
    def _find_conflicts(self, results: List[AnalysisResult]) -> List[str]:
        """Identify conflicting recommendations"""
        # Simple conflict detection - could be enhanced
        conflicts = []
        coding_recs = []
        ux_recs = []
        
        for result in results:
            if result.role in [ModelRole.CODING_PRIMARY, ModelRole.CODING_SECONDARY]:
                coding_recs.extend(result.recommendations)
            elif result.role in [ModelRole.UX_PRIMARY, ModelRole.UX_SECONDARY]:
                ux_recs.extend(result.recommendations)
        
        # Look for potential conflicts (this is simplified)
        if any("performance" in rec.lower() for rec in coding_recs) and \
           any("user experience" in rec.lower() for rec in ux_recs):
            conflicts.append("Potential performance vs UX trade-off identified")
        
        return conflicts
    
    def _determine_next_focus(self, results: List[AnalysisResult]) -> List[str]:
        """Determine focus areas for next round"""
        high_priority_areas = []
        
        for result in results:
            if result.priority_score >= 7:
                high_priority_areas.extend(result.recommendations[:2])
        
        return high_priority_areas[:5]  # Top 5 focus areas
    
    def save_analysis_report(self, output_path: str):
        """Save comprehensive analysis report"""
        report = {
            "orchestrator_summary": {
                "total_rounds": len(self.round_summaries),
                "total_analyses": len(self.analysis_history),
                "models_used": [config.name for config in self.models.values()]
            },
            "round_summaries": [asdict(summary) for summary in self.round_summaries],
            "detailed_analyses": [asdict(result) for result in self.analysis_history],
            "final_recommendations": self._generate_final_recommendations()
        }
        
        with open(output_path, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        logger.info(f"Analysis report saved to {output_path}")
    
    def _generate_final_recommendations(self) -> Dict[str, Any]:
        """Generate final consolidated recommendations"""
        if not self.round_summaries:
            return {}
        
        # Aggregate all high priority items
        all_high_priority = []
        for summary in self.round_summaries:
            all_high_priority.extend(summary.high_priority_items)
        
        # Get final synthesis
        final_synthesis = self.round_summaries[-1].synthesis_summary if self.round_summaries else ""
        
        return {
            "critical_issues": all_high_priority[:10],
            "consensus_recommendations": self.round_summaries[-1].consensus_items if self.round_summaries else [],
            "identified_gaps": self.round_summaries[-1].identified_gaps if self.round_summaries else [],
            "final_synthesis": final_synthesis,
            "implementation_priority": "Based on 6-model AI analysis across 5 rounds"
        }

# Convenience function for easy usage
async def run_multi_model_analysis(api_key: str, code_files: List[Tuple[str, str]], 
                                 num_rounds: int = 5) -> MultiModelOrchestrator:
    """Run complete multi-model analysis across specified rounds"""
    orchestrator = MultiModelOrchestrator(api_key)
    
    for round_num in range(1, num_rounds + 1):
        logger.info(f"Starting Round {round_num}/{num_rounds}")
        
        all_round_results = []
        for file_path, code_content in code_files:
            results = await orchestrator.analyze_code(code_content, file_path, round_num)
            all_round_results.extend(results)
        
        # Synthesize round results
        if all_round_results:
            round_summary = await orchestrator.synthesize_round(all_round_results)
            logger.info(f"Round {round_num} synthesis: {len(round_summary.high_priority_items)} high priority items")
    
    return orchestrator

