#!/usr/bin/env python3
"""
Test Script: Fixed 6-Model AI Analysis
Tests the corrected model IDs and runs a simplified analysis
"""

import asyncio
import os
import sys
from pathlib import Path
import logging

# Add the current directory to Python path
sys.path.append(str(Path(__file__).parent))

from fixed_orchestrator import run_fixed_multi_model_analysis, FixedMultiModelOrchestrator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

async def main():
    """Run the fixed 6-model analysis"""
    
    print("🚀 Testing Fixed 6-Model AI Analysis")
    print("=" * 50)
    print("Testing corrected model IDs:")
    print("• Claude Sonnet 4: anthropic/claude-sonnet-4")
    print("• DeepSeek V3: deepseek/deepseek-v3-0324:free")
    print("• Gemini 2.5 Flash: google/gemini-2.5-flash")
    print("• Gemini 2.5 Pro: google/gemini-2.5-pro")
    print("• Gemini 2.0 Flash: google/gemini-2.0-flash")
    print("• Claude 3.7 Sonnet: anthropic/claude-3.7-sonnet")
    print("=" * 50)
    
    # Get API key
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        print("❌ Error: OPENROUTER_API_KEY environment variable not set!")
        return
    
    # Test with a single file first
    framework_path = Path("../improved-framework")
    test_file = framework_path / "src/improved_agent.py"
    
    if not test_file.exists():
        print(f"❌ Test file not found: {test_file}")
        return
    
    try:
        with open(test_file, 'r') as f:
            content = f.read()
        
        print(f"✅ Loaded test file: {test_file} ({len(content)} chars)")
        
        # Test with just 1 round first
        code_files = [("src/improved_agent.py", content)]
        
        print("\n🤖 Starting 1-round test with 6 models...")
        print("This will test all model IDs and connections...")
        
        # Run the analysis
        orchestrator = await run_fixed_multi_model_analysis(
            api_key=api_key,
            code_files=code_files,
            num_rounds=1  # Just 1 round for testing
        )
        
        # Save test report
        report_path = "test_analysis_report.json"
        orchestrator.save_analysis_report(report_path)
        
        print(f"\n🎉 Test Complete!")
        print(f"📊 Report saved: {report_path}")
        
        # Show results
        if orchestrator.analysis_history:
            successful_models = len([r for r in orchestrator.analysis_history if "Analysis failed" not in r.findings])
            total_models = len(orchestrator.models)
            
            print(f"\n📈 Results:")
            print(f"  • Successful models: {successful_models}/{total_models}")
            print(f"  • Total analyses: {len(orchestrator.analysis_history)}")
            
            if orchestrator.round_summaries:
                summary = orchestrator.round_summaries[0]
                print(f"  • High priority items: {len(summary.high_priority_items)}")
                print(f"  • Consensus items: {len(summary.consensus_items)}")
            
            print(f"\n🔍 Model Results:")
            for result in orchestrator.analysis_history:
                status = "✅" if "Analysis failed" not in result.findings else "❌"
                print(f"  {status} {result.model_name}: Priority {result.priority_score}/10")
                if result.recommendations:
                    print(f"     → {result.recommendations[0][:60]}...")
        
        # If test successful, ask about full analysis
        if successful_models >= 4:  # At least 4 models working
            print(f"\n🎯 Test successful! {successful_models} models working.")
            response = input("Run full 5-round analysis? (y/N): ").strip().lower()
            
            if response == 'y':
                print("\n🚀 Starting full 5-round analysis...")
                
                # Load more files for full analysis
                key_files = [
                    "src/improved_agent.py",
                    "src/async_agent.py", 
                    "src/config.py",
                    "src/tools/math_tools.py"
                ]
                
                full_code_files = []
                for file_path in key_files:
                    full_path = framework_path / file_path
                    if full_path.exists():
                        with open(full_path, 'r') as f:
                            full_code_files.append((file_path, f.read()))
                
                # Run full analysis
                full_orchestrator = await run_fixed_multi_model_analysis(
                    api_key=api_key,
                    code_files=full_code_files,
                    num_rounds=5
                )
                
                # Save full report
                full_orchestrator.save_analysis_report("full_six_model_analysis.json")
                
                print(f"\n🎉 Full Analysis Complete!")
                print(f"📊 Full report: full_six_model_analysis.json")
                print(f"📈 Total analyses: {len(full_orchestrator.analysis_history)}")
        else:
            print(f"\n⚠️  Only {successful_models} models working. Check the errors above.")
            
    except Exception as e:
        logger.error(f"Test failed: {e}")
        print(f"❌ Test failed: {e}")

if __name__ == "__main__":
    asyncio.run(main())

