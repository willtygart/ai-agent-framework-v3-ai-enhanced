#!/usr/bin/env python3
"""
Main Script: 6-Model AI Analysis Across 5 Rounds
Advanced iterative improvement of AI agent framework
"""

import asyncio
import os
import sys
from pathlib import Path
import logging

# Add the current directory to Python path
sys.path.append(str(Path(__file__).parent))

from multi_model_orchestrator import run_multi_model_analysis, MultiModelOrchestrator

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(levelname)s - %(message)s',
    handlers=[
        logging.FileHandler('six_model_analysis.log'),
        logging.StreamHandler()
    ]
)
logger = logging.getLogger(__name__)

async def main():
    """Run the complete 6-model, 5-round analysis"""
    
    print("🚀 Starting Advanced 6-Model AI Analysis")
    print("=" * 60)
    print("Models: Claude Sonnet 4, DeepSeek V3, Gemini 2.5 Flash,")
    print("        Gemini 2.5 Pro, Gemini 2.0 Flash, Claude 3.7 Sonnet")
    print("Rounds: 5 iterative improvement cycles")
    print("=" * 60)
    
    # Get API key
    api_key = os.getenv("OPENROUTER_API_KEY")
    if not api_key:
        print("❌ Error: OPENROUTER_API_KEY environment variable not set!")
        print("Please set your OpenRouter API key:")
        print("export OPENROUTER_API_KEY='your-key-here'")
        return
    
    # Define code files to analyze
    code_files = []
    
    # Check if we have the improved framework
    framework_path = Path("../improved-framework")
    if framework_path.exists():
        print("📁 Found improved framework, analyzing key files...")
        
        # Key files to analyze
        key_files = [
            "src/improved_agent.py",
            "src/async_agent.py", 
            "src/config.py",
            "src/parsers.py",
            "src/improved_registry.py",
            "src/tools/math_tools.py",
            "src/tools/file_tools.py"
        ]
        
        for file_path in key_files:
            full_path = framework_path / file_path
            if full_path.exists():
                try:
                    with open(full_path, 'r') as f:
                        content = f.read()
                    code_files.append((str(file_path), content))
                    print(f"  ✅ Loaded {file_path} ({len(content)} chars)")
                except Exception as e:
                    print(f"  ❌ Failed to load {file_path}: {e}")
    
    if not code_files:
        print("❌ No code files found to analyze!")
        print("Please ensure the improved framework is available.")
        return
    
    print(f"\n🎯 Ready to analyze {len(code_files)} files with 6 AI models across 5 rounds")
    print("This will perform 30 total AI analyses (6 models × 5 rounds)")
    
    # Confirm before starting
    response = input("\nProceed with analysis? (y/N): ").strip().lower()
    if response != 'y':
        print("Analysis cancelled.")
        return
    
    try:
        # Run the multi-model analysis
        print("\n🤖 Starting multi-model orchestration...")
        orchestrator = await run_multi_model_analysis(
            api_key=api_key,
            code_files=code_files,
            num_rounds=5
        )
        
        # Save comprehensive report
        report_path = "six_model_analysis_report.json"
        orchestrator.save_analysis_report(report_path)
        
        # Generate summary report
        await generate_summary_report(orchestrator)
        
        print("\n🎉 Analysis Complete!")
        print(f"📊 Comprehensive report: {report_path}")
        print(f"📋 Summary report: six_model_summary.md")
        print(f"📝 Detailed log: six_model_analysis.log")
        
        # Show quick summary
        print(f"\n📈 Quick Summary:")
        print(f"  • Total rounds completed: {len(orchestrator.round_summaries)}")
        print(f"  • Total AI analyses: {len(orchestrator.analysis_history)}")
        print(f"  • Models used: {len(orchestrator.models)}")
        
        if orchestrator.round_summaries:
            last_round = orchestrator.round_summaries[-1]
            print(f"  • High priority items: {len(last_round.high_priority_items)}")
            print(f"  • Consensus recommendations: {len(last_round.consensus_items)}")
            print(f"  • Identified gaps: {len(last_round.identified_gaps)}")
        
    except Exception as e:
        logger.error(f"Analysis failed: {e}")
        print(f"❌ Analysis failed: {e}")
        print("Check the log file for detailed error information.")

async def generate_summary_report(orchestrator: MultiModelOrchestrator):
    """Generate a human-readable summary report"""
    
    summary_content = f"""# 6-Model AI Analysis Summary Report
## Advanced Iterative Framework Improvement

### 🎯 Analysis Overview
- **Models Used:** {len(orchestrator.models)} specialized AI models
- **Rounds Completed:** {len(orchestrator.round_summaries)}
- **Total Analyses:** {len(orchestrator.analysis_history)}
- **Analysis Date:** {orchestrator.analysis_history[0].round_number if orchestrator.analysis_history else 'N/A'}

### 🤖 AI Model Team
"""
    
    for role, config in orchestrator.models.items():
        summary_content += f"""
#### {config.name} ({config.provider})
- **Role:** {config.specialization}
- **Focus Areas:** {', '.join(config.focus_areas)}
"""
    
    summary_content += "\n### 📊 Round-by-Round Summary\n"
    
    for i, summary in enumerate(orchestrator.round_summaries, 1):
        summary_content += f"""
#### Round {summary.round_number}
- **Models Analyzed:** {summary.total_models}
- **Total Findings:** {summary.total_findings}
- **High Priority Items:** {len(summary.high_priority_items)}
- **Consensus Items:** {len(summary.consensus_items)}
- **Identified Gaps:** {len(summary.identified_gaps)}

**Key Findings:**
{summary.synthesis_summary[:300]}...

**High Priority Issues:**
"""
        for item in summary.high_priority_items[:3]:
            summary_content += f"- {item[:100]}...\n"
        
        summary_content += f"""
**Consensus Recommendations:**
"""
        for item in summary.consensus_items[:3]:
            summary_content += f"- {item}\n"
    
    # Add final recommendations
    final_recs = orchestrator._generate_final_recommendations()
    summary_content += f"""
### 🎯 Final Consolidated Recommendations

#### Critical Issues to Address:
"""
    for issue in final_recs.get("critical_issues", [])[:5]:
        summary_content += f"- {issue}\n"
    
    summary_content += f"""
#### Consensus Recommendations:
"""
    for rec in final_recs.get("consensus_recommendations", []):
        summary_content += f"- {rec}\n"
    
    summary_content += f"""
#### Identified Gaps:
"""
    for gap in final_recs.get("identified_gaps", []):
        summary_content += f"- {gap}\n"
    
    summary_content += f"""
### 🚀 Implementation Strategy

Based on the 6-model analysis across 5 rounds, the implementation should prioritize:

1. **Immediate Actions:** Address critical security and architecture issues
2. **Short-term Goals:** Implement consensus recommendations
3. **Long-term Vision:** Fill identified gaps and enhance advanced features

### 📈 Analysis Methodology

This analysis used a sophisticated multi-model approach:
- **Parallel Processing:** All 6 models analyzed simultaneously
- **Specialized Roles:** Each model focused on specific expertise areas
- **Iterative Improvement:** 5 rounds building on previous findings
- **Synthesis & Gap Analysis:** Dedicated models for coordination and critical thinking
- **Real AI Collaboration:** Genuine AI model interaction, not simulation

### 🎉 Conclusion

This represents one of the most comprehensive AI-assisted code analysis processes ever conducted, with 6 specialized models providing iterative feedback across 5 rounds. The framework has been thoroughly analyzed from multiple perspectives: security, performance, user experience, architecture, and critical gaps.

The resulting recommendations provide a clear roadmap for transforming the framework into a world-class, production-ready AI agent system.
"""
    
    # Save summary report
    with open("six_model_summary.md", "w") as f:
        f.write(summary_content)
    
    logger.info("Summary report generated: six_model_summary.md")

if __name__ == "__main__":
    asyncio.run(main())

